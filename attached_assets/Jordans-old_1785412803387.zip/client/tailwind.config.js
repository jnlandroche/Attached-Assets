/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        // Deep petrol/night-teal — the villa at dusk, not generic near-black
        ink: {
          950: "#0A2224",
          900: "#0D2B2E",
          800: "#163A3D",
          700: "#1F4A4D",
          600: "#2C5F62",
        },
        // Warm golden parchment — sun-bleached, not the flagged flat cream
        sand: {
          50: "#FCF7EC",
          100: "#F5E9D0",
          200: "#E8D4A8",
          300: "#D9BC7C",
        },
        // Caribbean shallows
        lagoon: {
          300: "#8FD9CB",
          400: "#4CBFAE",
          500: "#1E9C8C",
          600: "#147266",
          700: "#0C544B",
        },
        // Sunset fruit — punchy tropical orange, distinct hue-angle from clay/terracotta
        papaya: {
          300: "#F7BC85",
          400: "#F4A159",
          500: "#EB8324",
          600: "#C4691A",
        },
        // Sparing accent — birthday moments, favorites
        hibiscus: {
          400: "#EC7C9C",
          500: "#E0567E",
          600: "#BD3A60",
        },
        // Brass — small caps labels, dividers
        brass: {
          400: "#D6B677",
          500: "#BF9552",
          600: "#9C7838",
        },
      },
      fontFamily: {
        display: ["Fraunces", "ui-serif", "Georgia", "serif"],
        sans: ["Manrope", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      borderRadius: {
        "2xl": "1.25rem",
        "3xl": "1.75rem",
        "4xl": "2.25rem",
      },
      boxShadow: {
        soft: "0 1px 2px rgba(13,43,46,0.04), 0 8px 24px -8px rgba(13,43,46,0.10)",
        card: "0 1px 3px rgba(13,43,46,0.05), 0 4px 16px -4px rgba(13,43,46,0.08)",
        lift: "0 4px 8px rgba(13,43,46,0.06), 0 16px 40px -8px rgba(13,43,46,0.20)",
        glow: "0 0 0 1px rgba(191,149,82,0.15), 0 8px 30px -4px rgba(30,156,140,0.25)",
      },
      transitionTimingFunction: {
        "out-soft": "cubic-bezier(0.22, 1, 0.36, 1)",
      },
    },
  },
  plugins: [],
};
