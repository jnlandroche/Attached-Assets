import { NavLink, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Home, Palmtree, Users, Wallet, Plane, Compass, CalendarDays, Info } from "lucide-react";

const items = [
  { to: "/", label: "Home", icon: Home },
  { to: "/villa", label: "Villa", icon: Palmtree },
  { to: "/crew", label: "Crew", icon: Users },
  { to: "/money", label: "Money", icon: Wallet },
  { to: "/travel", label: "Travel", icon: Plane },
  { to: "/explore", label: "Explore", icon: Compass },
  { to: "/weekend", label: "Weekend", icon: CalendarDays },
  { to: "/need-to-know", label: "Info", icon: Info },
];

export default function BottomNav() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 pb-[env(safe-area-inset-bottom)]">
      <div className="bg-white/80 backdrop-blur-xl border-t border-ink-900/[0.06]">
        <div className="max-w-2xl mx-auto grid grid-cols-8">
          {items.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.to === "/" ? location.pathname === "/" : location.pathname === item.to;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                className="relative flex items-center justify-center py-3.5"
                aria-label={item.label}
              >
                {isActive && (
                  <motion.div
                    layoutId="navPill"
                    className="absolute inset-x-1.5 inset-y-2 rounded-2xl bg-lagoon-600"
                    transition={{ type: "spring", stiffness: 500, damping: 35 }}
                  />
                )}
                <Icon
                  className={`relative h-[21px] w-[21px] transition-colors duration-200 ${
                    isActive ? "text-white" : "text-ink-900/40"
                  }`}
                  strokeWidth={isActive ? 2.25 : 2}
                />
              </NavLink>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
