import { motion } from "framer-motion";

export default function PageHeader({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      className="px-5 pt-8 pb-5"
    >
      {eyebrow && (
        <div className="flex items-center gap-2 mb-2">
          <span className="h-px w-4 bg-brass-500" />
          <p className="text-[11px] font-bold tracking-[0.14em] text-brass-600 uppercase">
            {eyebrow}
          </p>
        </div>
      )}
      <h1 className="font-display text-[2.15rem] font-medium text-ink-900 leading-[1.08] tracking-tight">
        {title}
      </h1>
      {subtitle && (
        <p className="text-[15px] text-ink-900/45 mt-2 leading-snug max-w-[36ch]">{subtitle}</p>
      )}
    </motion.div>
  );
}
