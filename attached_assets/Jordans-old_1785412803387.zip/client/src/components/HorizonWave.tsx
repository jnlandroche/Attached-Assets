// The one recurring signature motif in this design: a single gentle wave,
// standing in for the horizon line at Chocolate Hole. Used at the hero/
// content seam on Home, and echoed quietly elsewhere — never as decoration,
// always at a genuine transition point (sea to land, photo to content).
export default function HorizonWave({
  className = "",
  color = "#FCF7EC",
}: {
  className?: string;
  color?: string;
}) {
  return (
    <svg
      viewBox="0 0 400 28"
      preserveAspectRatio="none"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M0 18C50 6 100 26 150 16C200 6 250 24 300 14C340 6 370 12 400 8V28H0V18Z"
        fill={color}
      />
    </svg>
  );
}
