import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../lib/utils.js";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-2xl text-sm font-semibold tracking-tight transition-all duration-200 ease-out-soft disabled:pointer-events-none disabled:opacity-40 active:scale-[0.97]",
  {
    variants: {
      variant: {
        default:
          "bg-ink-900 text-sand-50 hover:bg-ink-800 shadow-card hover:shadow-lift hover:-translate-y-px",
        primary:
          "bg-lagoon-600 text-white hover:bg-lagoon-500 shadow-card hover:shadow-lift hover:-translate-y-px",
        papaya:
          "bg-papaya-500 text-white hover:bg-papaya-600 shadow-card hover:shadow-lift hover:-translate-y-px",
        outline:
          "border border-ink-900/10 bg-white/80 text-ink-900 hover:bg-white hover:border-ink-900/20",
        soft: "bg-lagoon-600/8 text-lagoon-700 hover:bg-lagoon-600/14",
        ghost: "text-ink-900/70 hover:bg-ink-900/5 hover:text-ink-900",
        link: "text-lagoon-600 underline-offset-4 hover:underline px-0 h-auto",
      },
      size: {
        default: "h-12 px-5",
        sm: "h-10 px-4 text-xs",
        lg: "h-14 px-8 text-base",
        icon: "h-11 w-11",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
