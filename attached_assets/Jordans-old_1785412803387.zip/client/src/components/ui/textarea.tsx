import * as React from "react";
import { cn } from "../../lib/utils.js";

const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...props }, ref) => (
    <textarea
      ref={ref}
      className={cn(
        "flex min-h-20 w-full rounded-xl border border-sand-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 placeholder:text-ink-900/40 focus:outline-none focus:ring-2 focus:ring-lagoon-500/40 focus:border-lagoon-500 transition-colors",
        className
      )}
      {...props}
    />
  )
);
Textarea.displayName = "Textarea";

export { Textarea };
