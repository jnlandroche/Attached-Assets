import * as React from "react";
import { cn } from "../../lib/utils.js";

const Card = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        "rounded-3xl bg-white border border-ink-900/[0.06] shadow-card transition-shadow duration-300",
        className
      )}
      {...props}
    />
  )
);
Card.displayName = "Card";

// A Card variant for tappable/interactive rows — adds a gentle lift on
// hover (desktop) and a tighter compress on tap (mobile), instead of every
// card in the app sharing one flat static treatment.
const InteractiveCard = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        "rounded-3xl bg-white border border-ink-900/[0.06] shadow-card transition-all duration-300 ease-out-soft hover:shadow-lift hover:-translate-y-0.5 active:scale-[0.99] active:shadow-card cursor-pointer",
        className
      )}
      {...props}
    />
  )
);
InteractiveCard.displayName = "InteractiveCard";

const CardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("p-5 pb-3", className)} {...props} />
  )
);
CardHeader.displayName = "CardHeader";

const CardTitle = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h3 ref={ref} className={cn("font-display text-lg font-medium text-ink-900 tracking-tight", className)} {...props} />
  )
);
CardTitle.displayName = "CardTitle";

const CardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("p-5 pt-0", className)} {...props} />
  )
);
CardContent.displayName = "CardContent";

export { Card, InteractiveCard, CardHeader, CardTitle, CardContent };
