import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../lib/utils.js";

const badgeVariants = cva(
  "inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-bold tracking-wide",
  {
    variants: {
      variant: {
        default: "bg-ink-900/[0.06] text-ink-900/70",
        lagoon: "bg-lagoon-600/10 text-lagoon-700",
        papaya: "bg-papaya-500/10 text-papaya-600",
        brass: "bg-brass-500/15 text-brass-600",
        outline: "border border-ink-900/10 text-ink-900/70",
      },
    },
    defaultVariants: { variant: "default" },
  }
);

function Badge({ className, variant, ...props }: React.HTMLAttributes<HTMLDivElement> & VariantProps<typeof badgeVariants>) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
