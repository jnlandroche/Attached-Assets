import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import BottomNav from "./components/BottomNav.js";
import Home from "./pages/Home.js";
import Villa from "./pages/Villa.js";
import Crew from "./pages/Crew.js";
import Money from "./pages/Money.js";
import Travel from "./pages/Travel.js";
import Explore from "./pages/Explore.js";
import Weekend from "./pages/Weekend.js";
import NeedToKnow from "./pages/NeedToKnow.js";

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, y: 10, scale: 0.995 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -6, scale: 0.995 }}
        transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
      >
        <Routes location={location}>
          <Route path="/" element={<Home />} />
          <Route path="/villa" element={<Villa />} />
          <Route path="/crew" element={<Crew />} />
          <Route path="/money" element={<Money />} />
          <Route path="/travel" element={<Travel />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/weekend" element={<Weekend />} />
          <Route path="/need-to-know" element={<NeedToKnow />} />
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <div className="min-h-screen pb-24 bg-sand-50">
      <div className="max-w-2xl mx-auto">
        <AnimatedRoutes />
      </div>
      <BottomNav />
    </div>
  );
}
