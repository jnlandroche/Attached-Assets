import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Phone, MapPin, Ship, Car, AlertCircle } from "lucide-react";
import { api, Contact } from "../lib/api.js";
import { Card, CardContent } from "../components/ui/card.js";
import { Button } from "../components/ui/button.js";
import PageHeader from "../components/PageHeader.js";

const CATEGORY_LABELS: Record<string, string> = {
  emergency: "Emergency",
  hospital: "Hospital",
  urgent_care: "Urgent care",
  pharmacy: "Pharmacy",
  taxi: "Taxi & transportation",
  host: "Property host",
  other: "Other",
};

const ORDER = ["emergency", "hospital", "urgent_care", "pharmacy", "taxi", "host", "other"];

export default function NeedToKnow() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});

  useEffect(() => {
    api.get("/contacts").then(setContacts);
    api.get("/settings").then(setSettings);
  }, []);

  const grouped = ORDER.map((cat) => ({
    cat,
    items: contacts.filter((c) => c.category === cat),
  })).filter((g) => g.items.length > 0);

  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    settings.property_location || "Chocolate Hole, St. John, USVI"
  )}`;

  return (
    <div>
      <PageHeader eyebrow="Just in case" title="Need to know" subtitle="Save this page before you land — it works offline once loaded." />

      <div className="px-5 space-y-6">
        {/* Emergency banner */}
        <Card className="bg-papaya-500 border-none text-white">
          <CardContent className="p-5 flex items-center gap-3">
            <AlertCircle className="h-6 w-6 flex-shrink-0" />
            <div>
              <p className="font-display text-lg">In an emergency, call 911</p>
              <p className="text-white/80 text-sm">Works anywhere on St. John.</p>
            </div>
          </CardContent>
        </Card>

        {/* Ferry & getting around */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-3">
              <Ship className="h-4 w-4 text-lagoon-600" />
              <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em]">Ferry</p>
            </div>
            <p className="text-sm text-ink-900/70">
              St. John has no airport — most guests fly into St. Thomas (STT) and take the car
              barge or passenger ferry from Red Hook (or the seaplane base) across to Cruz Bay.
              Budget roughly an hour door-to-door from the St. Thomas airport.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-3">
              <Car className="h-4 w-4 text-papaya-500" />
              <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em]">Parking</p>
            </div>
            <p className="text-sm text-ink-900/70">
              The villa has parking for 3+ vehicles on-site. In Cruz Bay itself, parking is
              limited near the ferry dock — the Cruz Bay Battery lot and roadside spots along
              Route 104 fill up fast, especially when a cruise ship is in port.
            </p>
          </CardContent>
        </Card>

        {/* Contacts by category */}
        {grouped.map(({ cat, items }, gi) => (
          <div key={cat}>
            <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em] mb-3">
              {CATEGORY_LABELS[cat] ?? cat}
            </p>
            <div className="space-y-2.5">
              {items.map((c, i) => (
                <motion.div
                  key={c.id}
                  initial={{ opacity: 0, y: 8 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: (gi + i) * 0.02 }}
                >
                  <Card>
                    <CardContent className="p-4">
                      <p className="font-semibold text-ink-900 text-sm">{c.name}</p>
                      {c.phone && (
                        <a
                          href={`tel:${c.phone.replace(/[^\d+]/g, "")}`}
                          className="inline-flex items-center gap-1.5 text-lagoon-600 font-semibold text-sm mt-1"
                        >
                          <Phone className="h-3.5 w-3.5" /> {c.phone}
                        </a>
                      )}
                      {c.address && <p className="text-xs text-ink-900/50 mt-1">{c.address}</p>}
                      {c.notes && <p className="text-sm text-ink-900/60 mt-1.5">{c.notes}</p>}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        ))}

        <a href={mapsUrl} target="_blank" rel="noreferrer">
          <Button variant="outline" className="w-full">
            <MapPin className="h-4 w-4" /> Open villa location in Maps
          </Button>
        </a>
      </div>
    </div>
  );
}
