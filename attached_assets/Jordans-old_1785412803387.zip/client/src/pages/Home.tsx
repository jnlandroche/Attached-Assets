import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Wallet, Plane, Compass, Megaphone, ChevronRight, PartyPopper } from "lucide-react";
import { api, Balance, Guest, Household, Expense } from "../lib/api.js";
import { Card, CardContent, InteractiveCard } from "../components/ui/card.js";
import { Progress } from "../components/ui/progress.js";
import { Badge } from "../components/ui/badge.js";
import HorizonWave from "../components/HorizonWave.js";

const easeOut = [0.22, 1, 0.36, 1] as const;

export default function Home() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [balances, setBalances] = useState<Balance[]>([]);
  const [guests, setGuests] = useState<Guest[]>([]);
  const [households, setHouseholds] = useState<Household[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [heroIndex, setHeroIndex] = useState(0);

  useEffect(() => {
    api.get("/settings").then(setSettings);
    api.get("/balances").then(setBalances);
    api.get("/guests").then(setGuests);
    api.get("/households").then(setHouseholds);
    api.get("/expenses").then(setExpenses);
  }, []);

  const heroPhotos: string[] = settings.group_photos ? JSON.parse(settings.group_photos) : [];
  const birthdayPhotos: string[] = settings.birthday_photos
    ? JSON.parse(settings.birthday_photos)
    : [];

  useEffect(() => {
    if (heroPhotos.length < 2) return;
    const t = setInterval(() => setHeroIndex((i) => (i + 1) % heroPhotos.length), 5000);
    return () => clearInterval(t);
  }, [heroPhotos.length]);

  const checkIn = settings.check_in_date;
  const daysToGo = checkIn
    ? Math.ceil((new Date(checkIn).getTime() - Date.now()) / 86400000)
    : null;

  const totalSpent = balances.reduce((sum, b) => sum + b.totalPaid, 0);
  const targetBudget = settings.target_budget ? Number(settings.target_budget) : null;

  const householdName = (id: number) => households.find((h) => h.id === id)?.name ?? "";

  const upcomingArrivals = [...guests]
    .filter((g) => g.arrivalDatetime && new Date(g.arrivalDatetime) > new Date())
    .sort((a, b) => (a.arrivalDatetime! < b.arrivalDatetime! ? -1 : 1))
    .slice(0, 3);

  const latestExpenses = [...expenses].sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 3);
  const announcement = settings.announcement;

  return (
    <div className="pb-6">
      {/* ---- Hero: the countdown is the moment, not a stat pill ---- */}
      <div className="relative h-[68vh] min-h-[460px] overflow-hidden">
        {heroPhotos.map((src, i) => (
          <motion.img
            key={src}
            src={src}
            className="absolute inset-0 h-full w-full object-cover"
            initial={{ opacity: 0, scale: 1.08 }}
            animate={{
              opacity: i === heroIndex ? 1 : 0,
              scale: i === heroIndex ? 1 : 1.08,
            }}
            transition={{ duration: 1.6, ease: easeOut }}
          />
        ))}
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/25 to-ink-950/10" />
        <div className="absolute inset-0 bg-gradient-to-b from-ink-950/30 via-transparent to-transparent" />

        <div className="relative h-full flex flex-col justify-end px-6 pb-10">
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.5, ease: easeOut }}
            className="flex items-center gap-2 text-brass-400 text-[11px] font-bold tracking-[0.16em] uppercase mb-3"
          >
            <span className="h-px w-4 bg-brass-400" />
            {settings.property_location || "Chocolate Hole, St. John"}
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.6, ease: easeOut }}
            className="font-display text-[2.75rem] font-medium text-white leading-[0.98] tracking-tight max-w-[13ch]"
          >
            {settings.trip_title || "Jordan's 40th Birthday"}
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6, ease: easeOut }}
            className="flex items-end gap-4 mt-7"
          >
            {daysToGo !== null ? (
              <div className="flex items-baseline gap-2">
                <span className="font-display italic text-6xl text-white leading-none">
                  {daysToGo}
                </span>
                <span className="text-white/60 text-sm font-medium pb-1">
                  {daysToGo === 1 ? "day to go" : "days to go"}
                </span>
              </div>
            ) : (
              <p className="text-white/60 text-sm">Dates coming soon</p>
            )}
            {settings.weather_summary && (
              <p className="text-white/50 text-xs pb-1.5 border-l border-white/20 pl-4 max-w-[16ch] leading-snug">
                {settings.weather_summary}
              </p>
            )}
          </motion.div>
        </div>

        {/* Signature horizon seam into the page background */}
        <div className="absolute bottom-0 left-0 right-0 translate-y-px">
          <HorizonWave className="w-full h-7" color="#FCF7EC" />
        </div>
      </div>

      <div className="px-5 pt-1 space-y-4">
        {announcement && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, ease: easeOut }}
          >
            <Card className="bg-ink-900 border-none text-white">
              <CardContent className="p-4 flex items-start gap-3">
                <Megaphone className="h-5 w-5 text-brass-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-white/85 leading-relaxed">{announcement}</p>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Quick actions */}
        <div className="grid grid-cols-3 gap-2.5">
          {[
            { to: "/money", icon: Wallet, label: "Add expense", tint: "lagoon" },
            { to: "/travel", icon: Plane, label: "My flight", tint: "papaya" },
            { to: "/explore", icon: Compass, label: "Explore", tint: "brass" },
          ].map((a, i) => (
            <motion.div
              key={a.to}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + i * 0.06, duration: 0.4, ease: easeOut }}
            >
              <Link to={a.to}>
                <InteractiveCard className="h-full">
                  <CardContent className="p-4 flex flex-col items-center gap-2 text-center">
                    <div
                      className={`rounded-2xl p-2.5 ${
                        a.tint === "lagoon"
                          ? "bg-lagoon-600/10"
                          : a.tint === "papaya"
                          ? "bg-papaya-500/10"
                          : "bg-brass-500/15"
                      }`}
                    >
                      <a.icon
                        className={`h-5 w-5 ${
                          a.tint === "lagoon"
                            ? "text-lagoon-600"
                            : a.tint === "papaya"
                            ? "text-papaya-600"
                            : "text-brass-500"
                        }`}
                      />
                    </div>
                    <span className="text-[13px] font-semibold text-ink-900">{a.label}</span>
                  </CardContent>
                </InteractiveCard>
              </Link>
            </motion.div>
          ))}
        </div>

        {upcomingArrivals.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.45, ease: easeOut }}
          >
            <Card>
              <CardContent className="p-5">
                <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em] mb-3.5">
                  Arriving next
                </p>
                <div className="space-y-3.5">
                  {upcomingArrivals.map((g) => (
                    <div key={g.id} className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-ink-900 text-[15px]">{g.name}</p>
                        <p className="text-xs text-ink-900/45">{householdName(g.householdId)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-ink-900">
                          {new Date(g.arrivalDatetime!).toLocaleDateString(undefined, {
                            weekday: "short",
                            month: "short",
                            day: "numeric",
                          })}
                        </p>
                        <p className="text-xs text-ink-900/45">
                          {new Date(g.arrivalDatetime!).toLocaleTimeString(undefined, {
                            hour: "numeric",
                            minute: "2-digit",
                          })}
                          {g.arrivalFlightNumber ? ` · ${g.arrivalFlightNumber}` : ""}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Money at a glance — progress, balances, and recent activity in
            one place rather than three separate cards competing for space. */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.45, ease: easeOut }}
        >
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-1">
                <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em]">
                  Trip spend
                </p>
                <p className="font-display text-2xl text-ink-900">
                  ${totalSpent.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </p>
              </div>
              {targetBudget && (
                <div className="mb-4 mt-2">
                  <Progress value={Math.min(100, (totalSpent / targetBudget) * 100)} />
                  <p className="text-xs text-ink-900/40 mt-1.5">
                    of ${targetBudget.toLocaleString()} planned
                  </p>
                </div>
              )}

              <div className="space-y-2 mt-4">
                {balances.map((b) => (
                  <div key={b.householdId} className="flex justify-between items-center text-sm">
                    <span className="font-medium text-ink-900">{b.householdName}</span>
                    <Badge variant={b.netBalance >= 0 ? "lagoon" : "papaya"}>
                      {b.netBalance >= 0 ? "+" : ""}${b.netBalance.toFixed(0)}
                    </Badge>
                  </div>
                ))}
              </div>

              {latestExpenses.length > 0 && (
                <div className="mt-4 pt-4 border-t border-ink-900/[0.06] space-y-3">
                  {latestExpenses.map((e) => (
                    <div key={e.id} className="flex justify-between items-center">
                      <div>
                        <p className="text-[13px] font-semibold text-ink-900">{e.description}</p>
                        <p className="text-xs text-ink-900/45">
                          {e.category}
                          {e.merchant ? ` · ${e.merchant}` : ""}
                        </p>
                      </div>
                      <p className="font-semibold text-ink-900 text-[13px]">
                        ${Number(e.totalAmount).toFixed(0)}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              <Link
                to="/money"
                className="flex items-center gap-1 text-sm font-semibold text-lagoon-600 mt-4 group"
              >
                Open the ledger
                <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </Link>
            </CardContent>
          </Card>
        </motion.div>

        {birthdayPhotos.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.45, ease: easeOut }}
          >
            <div className="flex items-center gap-2 mb-3 px-0.5">
              <PartyPopper className="h-4 w-4 text-papaya-500" />
              <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em]">
                Jordan turns 40
              </p>
            </div>
            <div className="flex gap-2.5 overflow-x-auto no-scrollbar pb-1 -mx-5 px-5">
              {birthdayPhotos.map((src) => (
                <motion.img
                  key={src}
                  src={src}
                  whileTap={{ scale: 0.95 }}
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                  className="h-36 w-36 object-cover rounded-2xl flex-shrink-0 shadow-card"
                />
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
