import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Plane, Home as HomeIcon } from "lucide-react";
import { api, Household, Room, Guest } from "../lib/api.js";
import { Card, CardContent } from "../components/ui/card.js";
import { Avatar, AvatarFallback } from "../components/ui/avatar.js";
import PageHeader from "../components/PageHeader.js";

function initials(name: string) {
  return name
    .split(/[\s&]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join("");
}

export default function Crew() {
  const [households, setHouseholds] = useState<Household[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [guests, setGuests] = useState<Guest[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});

  useEffect(() => {
    api.get("/households").then(setHouseholds);
    api.get("/rooms").then(setRooms);
    api.get("/guests").then(setGuests);
    api.get("/settings").then(setSettings);
  }, []);

  const groupPhotos: string[] = settings.group_photos ? JSON.parse(settings.group_photos) : [];

  const roomFor = (householdId: number) =>
    rooms.find((r) => r.assignedHouseholdId === householdId)?.name;

  const guestsFor = (householdId: number) =>
    guests.filter((g) => g.householdId === householdId);

  return (
    <div>
      <PageHeader eyebrow="Who's here" title="The crew" subtitle="Four households, one villa." />

      <div className="px-5 space-y-6">
        {groupPhotos.length > 0 && (
          <div className="flex gap-2.5 overflow-x-auto no-scrollbar pb-1 -mx-5 px-5">
            {groupPhotos.map((src) => (
              <img
                key={src}
                src={src}
                className="h-36 w-52 object-cover rounded-2xl flex-shrink-0 shadow-card"
              />
            ))}
          </div>
        )}

        <div className="space-y-3">
          {households.map((h, i) => {
            const room = roomFor(h.id);
            const hGuests = guestsFor(h.id);
            return (
              <motion.div
                key={h.id}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-30px" }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
              >
                <Card>
                  <CardContent className="p-5">
                    <div className="flex items-center gap-3 mb-3">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-lagoon-600">
                          {initials(h.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-display text-lg text-ink-900">{h.name}</p>
                        {room && (
                          <p className="text-xs text-ink-900/50 flex items-center gap-1 mt-0.5">
                            <HomeIcon className="h-3 w-3" /> {room}
                          </p>
                        )}
                      </div>
                    </div>

                    {hGuests.length > 0 && (
                      <div className="space-y-2 pt-3 border-t border-sand-100">
                        {hGuests.map((g) => (
                          <div key={g.id} className="flex items-center justify-between text-sm">
                            <span className="font-medium text-ink-900/80">{g.name}</span>
                            <div className="text-right text-xs text-ink-900/50">
                              {g.arrivalDatetime && (
                                <p className="flex items-center gap-1 justify-end">
                                  <Plane className="h-3 w-3" />
                                  {new Date(g.arrivalDatetime).toLocaleDateString(undefined, {
                                    month: "short",
                                    day: "numeric",
                                  })}
                                  {g.arrivalFlightNumber ? ` · ${g.arrivalFlightNumber}` : ""}
                                </p>
                              )}
                              {g.departureDatetime && (
                                <p>
                                  Departs{" "}
                                  {new Date(g.departureDatetime).toLocaleDateString(undefined, {
                                    month: "short",
                                    day: "numeric",
                                  })}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {h.notes && (
                      <p className="text-xs text-ink-900/50 mt-3 pt-3 border-t border-sand-100">
                        {h.notes}
                      </p>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
