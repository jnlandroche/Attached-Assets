import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { MapPin, Wifi, Waves, UtensilsCrossed, Car, Zap, ExternalLink, Pencil, Users } from "lucide-react";
import { api, Room, Household } from "../lib/api.js";
import { Card, CardContent } from "../components/ui/card.js";
import { Button } from "../components/ui/button.js";
import { Textarea } from "../components/ui/textarea.js";
import { Input } from "../components/ui/input.js";
import { Label } from "../components/ui/label.js";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "../components/ui/select.js";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog.js";
import PageHeader from "../components/PageHeader.js";

const ROOM_ACCENTS = ["bg-lagoon-600", "bg-papaya-500", "bg-brass-500", "bg-ink-700"];

const AMENITIES = [
  { icon: Waves, label: "Private pool" },
  { icon: UtensilsCrossed, label: "Two full kitchens" },
  { icon: Wifi, label: "Fast Wi-Fi throughout" },
  { icon: Car, label: "Parking for 3+ vehicles" },
  { icon: Zap, label: "Tesla Powerwall backup" },
];

export default function Villa() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [households, setHouseholds] = useState<Household[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [editingRules, setEditingRules] = useState(false);
  const [rulesDraft, setRulesDraft] = useState("");
  const [checkInDraft, setCheckInDraft] = useState("");
  const [checkOutDraft, setCheckOutDraft] = useState("");

  const load = () => {
    api.get("/rooms").then(setRooms);
    api.get("/households").then(setHouseholds);
    api.get("/settings").then((s) => {
      setSettings(s);
      setRulesDraft(s.house_rules ?? "");
      setCheckInDraft(s.check_in_time ?? "");
      setCheckOutDraft(s.check_out_time ?? "");
    });
  };
  useEffect(load, []);

  const saveRules = async () => {
    await api.patch("/settings", {
      house_rules: rulesDraft,
      check_in_time: checkInDraft,
      check_out_time: checkOutDraft,
    });
    setEditingRules(false);
    load();
  };

  const assign = async (roomId: number, householdId: string) => {
    await api.patch(`/rooms/${roomId}`, {
      assignedHouseholdId: householdId ? Number(householdId) : null,
    });
    load();
  };

  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    settings.property_location || "Chocolate Hole, St. John, USVI"
  )}`;

  return (
    <div>
      <PageHeader
        eyebrow="The villa"
        title={settings.property_name || "Terrapin Station"}
        subtitle={settings.property_location}
      />

      {/* Gallery — real photos from the VRBO listing */}
      {settings.villa_gallery && (
        <div className="flex gap-2.5 overflow-x-auto no-scrollbar pb-1 px-5 mb-1">
          {(JSON.parse(settings.villa_gallery) as string[]).map((src) => (
            <img
              key={src}
              src={src}
              className="h-40 w-56 object-cover rounded-2xl flex-shrink-0 shadow-card"
            />
          ))}
        </div>
      )}

      <div className="px-5 space-y-6 mt-4">
        {settings.guest_rating && (
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-ink-900">{settings.guest_rating}</span>
          </div>
        )}
        {settings.vrbo_url && (
          <a
            href={settings.vrbo_url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-lagoon-600"
          >
            View original listing <ExternalLink className="h-3.5 w-3.5" />
          </a>
        )}

        {/* Check-in / Check-out */}
        <div className="grid grid-cols-2 gap-3">
          <Card>
            <CardContent className="p-4">
              <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em]">Check-in</p>
              <p className="font-display text-lg text-ink-900 mt-0.5">
                {settings.check_in_time || "TBD"}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em]">Check-out</p>
              <p className="font-display text-lg text-ink-900 mt-0.5">
                {settings.check_out_time || "TBD"}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Rooms */}
        <div>
          <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em] mb-3">
            Bedrooms
          </p>
          <div className="space-y-3">
            {rooms.map((room, i) => (
              <motion.div
                key={room.id}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.35, delay: i * 0.05 }}
              >
                <Card className="overflow-hidden">
                  <div
                    className={`h-40 flex items-end p-4 ${
                      room.photoUrl ? "" : ROOM_ACCENTS[i % ROOM_ACCENTS.length]
                    }`}
                    style={
                      room.photoUrl
                        ? {
                            backgroundImage: `linear-gradient(0deg, rgba(14,42,46,0.55), rgba(14,42,46,0.05)), url(${room.photoUrl})`,
                            backgroundSize: "cover",
                            backgroundPosition: "center",
                          }
                        : undefined
                    }
                  >
                    <p className="text-white font-display text-lg">{room.name}</p>
                  </div>
                  <CardContent className="p-4 pt-3">
                    <p className="text-sm text-ink-900/70">{room.bedConfig}</p>
                    <p className="text-sm text-ink-900/50 mt-1">{room.bathLayout}</p>
                    {room.occupancy && (
                      <p className="text-xs text-ink-900/50 mt-1.5 flex items-center gap-1.5">
                        <Users className="h-3.5 w-3.5" /> Sleeps {room.occupancy}
                      </p>
                    )}
                    {room.notes && (
                      <p className="text-xs text-ink-900/40 mt-1.5 italic">{room.notes}</p>
                    )}
                    <div className="mt-3">
                      <Select
                        value={room.assignedHouseholdId ? String(room.assignedHouseholdId) : undefined}
                        onValueChange={(v) => assign(room.id, v)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Unassigned" />
                        </SelectTrigger>
                        <SelectContent>
                          {households.map((h) => (
                            <SelectItem key={h.id} value={String(h.id)}>
                              {h.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Amenities */}
        <div>
          <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em] mb-3">
            Amenities
          </p>
          <Card>
            <CardContent className="p-5 grid grid-cols-2 gap-4">
              {AMENITIES.map((a) => {
                const Icon = a.icon;
                return (
                  <div key={a.label} className="flex items-center gap-2.5">
                    <Icon className="h-4.5 w-4.5 text-lagoon-600 flex-shrink-0" />
                    <span className="text-sm text-ink-900/80">{a.label}</span>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>

        {/* House rules */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em]">
              Good to know
            </p>
            <Button variant="link" size="sm" onClick={() => setEditingRules(true)}>
              <Pencil className="h-3 w-3" /> Edit
            </Button>
          </div>
          <Card>
            <CardContent className="p-5 space-y-2 text-sm text-ink-900/70">
              <p>100% of the living area is air conditioned.</p>
              <p>Two full refrigerators plus an outdoor grill.</p>
              <p>Major 2020 renovation: all-new kitchen, primary bath, guest suite, AC, furnishings.</p>
              <p>Upstairs open floor plan overlooks Chocolate Hole and Hart Bay, with St. Thomas to the west and St. Croix to the south.</p>
              {settings.house_rules && (
                <p className="pt-2 border-t border-sand-100 whitespace-pre-line">
                  {settings.house_rules}
                </p>
              )}
              {!settings.house_rules && (
                <p className="pt-2 border-t border-sand-100 text-ink-900/40 italic">
                  No house rules added yet from the host — tap Edit to add any (quiet hours, pool
                  rules, etc.) once you have them.
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Location */}
        <div>
          <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em] mb-3">
            Location
          </p>
          <Card>
            <CardContent className="p-5">
              <div className="flex items-start gap-3 mb-3">
                <MapPin className="h-5 w-5 text-papaya-500 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-ink-900/80">{settings.property_location}</p>
              </div>
              <div className="space-y-1.5 text-sm text-ink-900/60 mb-4">
                <p>Rendezvous Bay — 1 min drive</p>
                <p>Great Cruz Bay — ~4 min drive / 18 min walk</p>
                <p>Chocolate Hole Beach — 3 min drive</p>
                <p>Cruz Bay (town) — ~10-12 min drive</p>
              </div>
              <a href={mapsUrl} target="_blank" rel="noreferrer">
                <Button variant="outline" className="w-full">
                  Get directions
                </Button>
              </a>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Edit house rules / check-in dialog */}
      <Dialog open={editingRules} onOpenChange={setEditingRules}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Villa details</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <Label>Check-in</Label>
                <Input
                  className="mt-1"
                  placeholder="e.g. 4:00 PM"
                  value={checkInDraft}
                  onChange={(e) => setCheckInDraft(e.target.value)}
                />
              </div>
              <div>
                <Label>Check-out</Label>
                <Input
                  className="mt-1"
                  placeholder="e.g. 10:00 AM"
                  value={checkOutDraft}
                  onChange={(e) => setCheckOutDraft(e.target.value)}
                />
              </div>
            </div>
            <div>
              <Label>House rules</Label>
              <Textarea
                className="mt-1"
                placeholder="Quiet hours, pool rules, parking notes, anything the host asked for..."
                value={rulesDraft}
                onChange={(e) => setRulesDraft(e.target.value)}
                rows={5}
              />
            </div>
            <Button variant="primary" className="w-full" onClick={saveRules}>
              Save
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
