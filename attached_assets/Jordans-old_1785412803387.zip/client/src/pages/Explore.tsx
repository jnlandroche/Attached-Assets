import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  UtensilsCrossed,
  Martini,
  Mountain,
  Waves,
  Coffee,
  ShoppingBasket,
  Sailboat,
  MapPin,
  ExternalLink,
  Heart,
} from "lucide-react";
import { api, GuideEntry } from "../lib/api.js";
import { Card, CardContent } from "../components/ui/card.js";
import { Button } from "../components/ui/button.js";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs.js";
import PageHeader from "../components/PageHeader.js";

const TABS: { key: GuideEntry["type"]; label: string; icon: typeof UtensilsCrossed; accent: string }[] = [
  { key: "dining", label: "Dining", icon: UtensilsCrossed, accent: "bg-papaya-500" },
  { key: "bar", label: "Bars", icon: Martini, accent: "bg-brass-500" },
  { key: "activity", label: "Hikes & Do", icon: Mountain, accent: "bg-lagoon-600" },
  { key: "beach", label: "Beaches", icon: Waves, accent: "bg-lagoon-400" },
  { key: "boat", label: "Boats", icon: Sailboat, accent: "bg-ink-700" },
  { key: "coffee", label: "Coffee", icon: Coffee, accent: "bg-papaya-400" },
  { key: "grocery", label: "Groceries", icon: ShoppingBasket, accent: "bg-brass-400" },
];

export default function Explore() {
  const [tab, setTab] = useState<GuideEntry["type"]>("dining");
  const [entries, setEntries] = useState<GuideEntry[]>([]);

  const load = (t: GuideEntry["type"]) => api.get(`/guide?type=${t}`).then(setEntries);
  useEffect(() => {
    load(tab);
  }, [tab]);

  const activeTab = TABS.find((t) => t.key === tab)!;

  const toggleFavorite = async (entry: GuideEntry) => {
    await api.patch(`/guide/${entry.id}`, { favorited: !entry.favorited });
    load(tab);
  };

  return (
    <div>
      <PageHeader eyebrow="Off the villa" title="Explore" subtitle="Everything within a short drive." />

      <div className="px-5">
        <Tabs value={tab} onValueChange={(v) => setTab(v as GuideEntry["type"])}>
          <TabsList>
            {TABS.map((t) => (
              <TabsTrigger key={t.key} value={t.key}>
                {t.label}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value={tab}>
            <div className="space-y-4">
              {entries.map((e, i) => {
                const Icon = activeTab.icon;
                return (
                  <motion.div
                    key={e.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04, duration: 0.25 }}
                  >
                    <Card className="overflow-hidden">
                      {/* Editorial header — photo if the entry has one, otherwise a
                          tasteful color-and-icon treatment (no stock photography). */}
                      <div
                        className={`h-36 relative flex items-end p-4 ${
                          e.photoUrl ? "" : activeTab.accent
                        }`}
                        style={
                          e.photoUrl
                            ? {
                                backgroundImage: `linear-gradient(0deg, rgba(14,42,46,0.55), rgba(14,42,46,0.05)), url(${e.photoUrl})`,
                                backgroundSize: "cover",
                                backgroundPosition: "center",
                              }
                            : undefined
                        }
                      >
                        {!e.photoUrl && (
                          <Icon className="absolute top-4 right-4 h-7 w-7 text-white/40" />
                        )}
                        <div className="flex items-center justify-between w-full">
                          <p className="font-display text-lg text-white leading-tight">{e.name}</p>
                          <button
                            onClick={() => toggleFavorite(e)}
                            className="rounded-full bg-black/20 backdrop-blur-sm p-2 tap"
                          >
                            <Heart
                              className={`h-4 w-4 ${
                                e.favorited ? "fill-papaya-400 text-papaya-400" : "text-white"
                              }`}
                            />
                          </button>
                        </div>
                      </div>

                      <CardContent className="p-4">
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          {e.subtitle && <p className="text-xs text-ink-900/50">{e.subtitle}</p>}
                          {e.priceTier && (
                            <span className="text-xs font-bold text-lagoon-600 flex-shrink-0">
                              {e.priceTier}
                            </span>
                          )}
                        </div>
                        {e.distanceFromVilla && (
                          <p className="text-xs text-ink-900/40 mb-1.5">📍 {e.distanceFromVilla}</p>
                        )}
                        {e.notes && (
                          <p className="text-sm text-ink-900/70 leading-relaxed">{e.notes}</p>
                        )}

                        <div className="flex gap-2 mt-3.5">
                          {e.mapUrl && (
                            <a href={e.mapUrl} target="_blank" rel="noreferrer" className="flex-1">
                              <Button variant="outline" size="sm" className="w-full">
                                <MapPin className="h-3.5 w-3.5" /> Maps
                              </Button>
                            </a>
                          )}
                          {e.websiteUrl && (
                            <a href={e.websiteUrl} target="_blank" rel="noreferrer" className="flex-1">
                              <Button variant="outline" size="sm" className="w-full">
                                <ExternalLink className="h-3.5 w-3.5" /> Website
                              </Button>
                            </a>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
              {entries.length === 0 && (
                <p className="text-sm text-ink-900/40 text-center py-8">Nothing here yet.</p>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
