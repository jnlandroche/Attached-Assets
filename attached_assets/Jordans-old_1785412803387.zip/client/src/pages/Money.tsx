import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Camera, X, Check, Receipt as ReceiptIcon, PartyPopper } from "lucide-react";
import {
  api,
  Expense,
  Household,
  Balance,
  SettlementRecommendation,
  Settlement,
} from "../lib/api.js";
import { Card, CardContent } from "../components/ui/card.js";
import { Button } from "../components/ui/button.js";
import { Input } from "../components/ui/input.js";
import { Textarea } from "../components/ui/textarea.js";
import { Label } from "../components/ui/label.js";
import { Checkbox } from "../components/ui/checkbox.js";
import { Progress } from "../components/ui/progress.js";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "../components/ui/select.js";
import { Dialog, DialogContent } from "../components/ui/dialog.js";
import PageHeader from "../components/PageHeader.js";

const CATEGORIES = [
  "Lodging",
  "Food & Drink",
  "Groceries",
  "Transportation",
  "Activities",
  "Entertainment",
  "Other",
];

const METHODS = [
  { value: "equal_all", label: "Split equally — everyone" },
  { value: "equal_selected", label: "Split equally — selected households" },
  { value: "percentage", label: "Custom percentages" },
  { value: "fixed", label: "Custom dollar amounts" },
  { value: "single_payer", label: "One household only" },
];

// Each household gets a distinct "wallet card" skin — deep, editorial
// tones rather than a repeated white card, so the balances feel like
// individual cards in a wallet rather than rows in a table.
const WALLET_SKINS = [
  "bg-gradient-to-br from-ink-800 to-ink-950",
  "bg-gradient-to-br from-lagoon-600 to-ink-800",
  "bg-gradient-to-br from-papaya-600 to-ink-900",
  "bg-gradient-to-br from-brass-600 to-ink-900",
];

const easeOut = [0.22, 1, 0.36, 1] as const;

function initials(name: string) {
  return name
    .split(/[\s&]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join("");
}

type ShareDraft = Record<number, number>;

export default function Money() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [households, setHouseholds] = useState<Household[]>([]);
  const [balances, setBalances] = useState<Balance[]>([]);
  const [recs, setRecs] = useState<SettlementRecommendation[]>([]);
  const [allSettlements, setAllSettlements] = useState<Settlement[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [justSettled, setJustSettled] = useState<number | null>(null);

  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [description, setDescription] = useState("");
  const [merchant, setMerchant] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [paidBy, setPaidBy] = useState<string>("");
  const [totalAmount, setTotalAmount] = useState("");
  const [method, setMethod] = useState("equal_all");
  const [selected, setSelected] = useState<Record<number, boolean>>({});
  const [customShares, setCustomShares] = useState<ShareDraft>({});
  const [notes, setNotes] = useState("");
  const [receiptUrl, setReceiptUrl] = useState("");

  const load = () => {
    api.get("/expenses").then(setExpenses);
    api.get("/households").then((hh: Household[]) => {
      setHouseholds(hh);
      setSelected((prev) =>
        Object.keys(prev).length ? prev : Object.fromEntries(hh.map((h) => [h.id, true]))
      );
    });
    api.get("/balances").then(setBalances);
    api.get("/settlements/recommendations").then((r) => setRecs(r.recommendations));
    api.get("/settlements").then(setAllSettlements);
  };
  useEffect(load, []);

  const total = Number(totalAmount) || 0;

  const resolvedShares = useMemo(() => {
    const activeIds = households.filter((h) => selected[h.id]).map((h) => h.id);
    if (method === "single_payer") {
      return paidBy ? [{ householdId: Number(paidBy), shareAmount: total }] : [];
    }
    if (method === "equal_all" || method === "equal_selected") {
      const ids = method === "equal_all" ? households.map((h) => h.id) : activeIds;
      if (ids.length === 0) return [];
      const per = Math.round((total / ids.length) * 100) / 100;
      return ids.map((id) => ({ householdId: id, shareAmount: per }));
    }
    if (method === "percentage") {
      return activeIds.map((id) => ({
        householdId: id,
        shareAmount: Math.round(((customShares[id] ?? 0) / 100) * total * 100) / 100,
      }));
    }
    if (method === "fixed") {
      return activeIds.map((id) => ({ householdId: id, shareAmount: customShares[id] ?? 0 }));
    }
    return [];
  }, [method, selected, customShares, households, total, paidBy]);

  const shareTotal = resolvedShares.reduce((s, r) => s + r.shareAmount, 0);
  const participantIds =
    method === "single_payer"
      ? paidBy
        ? [Number(paidBy)]
        : []
      : households.filter((h) => selected[h.id]).map((h) => h.id);

  const handleReceiptSelect = async (file: File) => {
    setUploading(true);
    const formData = new FormData();
    formData.append("receipt", file);
    try {
      const result = await api.upload("/upload/receipt", formData);
      setReceiptUrl(result.url);
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setDescription("");
    setMerchant("");
    setTotalAmount("");
    setNotes("");
    setReceiptUrl("");
    setShowForm(false);
  };

  const submit = async () => {
    if (!description || !total || !paidBy) return;
    await api.post("/expenses", {
      date,
      description,
      merchant,
      category,
      paidByHouseholdId: Number(paidBy),
      totalAmount: total,
      allocationMethod: method,
      notes,
      receiptUrl: receiptUrl || undefined,
      participantHouseholdIds: participantIds,
      shares: resolvedShares,
    });
    resetForm();
    load();
  };

  const remove = async (id: number) => {
    await api.del(`/expenses/${id}`);
    load();
  };

  const householdName = (id: number | null) => households.find((h) => h.id === id)?.name ?? "—";

  const markSettled = async (rec: SettlementRecommendation, index: number) => {
    setJustSettled(index);
    const created = await api.post("/settlements", {
      fromHouseholdId: rec.fromHouseholdId,
      toHouseholdId: rec.toHouseholdId,
      amount: rec.amount,
    });
    await api.patch(`/settlements/${created.id}`, { status: "paid" });
    setTimeout(() => {
      load();
      setJustSettled(null);
    }, 550);
  };

  const totalOwed = recs.reduce((s, r) => s + r.amount, 0);
  const totalPaidSettlements = allSettlements
    .filter((s) => s.status === "paid")
    .reduce((s, x) => s + Number(x.amount), 0);
  const settlementDone = totalOwed < 0.01;
  const settlementPct =
    totalPaidSettlements + totalOwed < 0.01
      ? 100
      : Math.round((totalPaidSettlements / (totalPaidSettlements + totalOwed)) * 100);

  return (
    <div>
      <PageHeader
        eyebrow="The ledger"
        title="Money"
        subtitle="Every dollar, every household, always current."
      />

      <div className="space-y-6">
        {/* ---- Wallet-card balances — swipeable, one card per household ---- */}
        <div>
          <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em] px-5 mb-3">
            Balances
          </p>
          <div className="flex gap-3 overflow-x-auto no-scrollbar px-5 pb-1 snap-x snap-mandatory">
            {balances.map((b, i) => {
              const settled = Math.abs(b.netBalance) < 0.01;
              return (
                <motion.div
                  key={b.householdId}
                  initial={{ opacity: 0, x: 16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06, duration: 0.4, ease: easeOut }}
                  className={`relative flex-shrink-0 w-[78%] max-w-[260px] rounded-3xl p-5 text-white snap-start overflow-hidden shadow-lift ${
                    WALLET_SKINS[i % WALLET_SKINS.length]
                  }`}
                >
                  <div
                    className="absolute -right-6 -top-6 h-28 w-28 rounded-full bg-white/[0.06]"
                    aria-hidden
                  />
                  <div className="relative">
                    <div className="flex items-center justify-between mb-6">
                      <span className="text-xs font-bold uppercase tracking-wider text-white/50">
                        {initials(b.householdName)}
                      </span>
                      {settled && (
                        <span className="flex items-center gap-1 text-[11px] font-semibold text-white/70">
                          <Check className="h-3 w-3" /> Settled
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-white/70 mb-0.5">{b.householdName}</p>
                    <p className="font-display text-3xl tracking-tight">
                      {settled ? (
                        "—"
                      ) : (
                        <>
                          {b.netBalance >= 0 ? "+" : "−"}${Math.abs(b.netBalance).toFixed(2)}
                        </>
                      )}
                    </p>
                    <div className="flex justify-between text-[11px] text-white/50 mt-4 pt-3 border-t border-white/10">
                      <span>Paid ${b.totalPaid.toFixed(0)}</span>
                      <span>Share ${b.totalShare.toFixed(0)}</span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        <div className="px-5 space-y-6">
          {/* ---- Settlement tracker ---- */}
          <Card>
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-1">
                <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em]">
                  Settle up
                </p>
                {settlementDone && (
                  <span className="flex items-center gap-1.5 text-lagoon-600 text-sm font-semibold">
                    <PartyPopper className="h-4 w-4" /> All settled
                  </span>
                )}
              </div>

              {!settlementDone && (
                <>
                  <div className="flex items-baseline justify-between mt-3 mb-1.5">
                    <span className="font-display text-2xl text-ink-900">{settlementPct}%</span>
                    <span className="text-xs text-ink-900/40">settled</span>
                  </div>
                  <Progress value={settlementPct} className="mb-4" />
                  <div className="space-y-2">
                    {recs.map((r, i) => (
                      <motion.label
                        key={i}
                        animate={justSettled === i ? { scale: [1, 1.02, 1] } : {}}
                        className={`relative flex items-center gap-3 rounded-2xl p-3.5 cursor-pointer transition-colors ${
                          justSettled === i ? "bg-lagoon-600/10" : "bg-sand-50 hover:bg-sand-100"
                        }`}
                      >
                        <Checkbox
                          checked={justSettled === i}
                          onCheckedChange={(c) => c && markSettled(r, i)}
                        />
                        <div className="flex-1">
                          <div className="text-sm flex items-center gap-1.5">
                            <span className="font-semibold text-ink-900">{r.fromName}</span>
                            <span className="text-ink-900/35">→</span>
                            <span className="font-semibold text-ink-900">{r.toName}</span>
                          </div>
                          <span className="text-xs text-ink-900/40">
                            {justSettled === i ? "Paid" : "Pending"}
                          </span>
                        </div>
                        <span className="font-display text-lg text-ink-900">
                          ${r.amount.toFixed(2)}
                        </span>
                      </motion.label>
                    ))}
                  </div>
                </>
              )}
              {settlementDone && recs.length === 0 && (
                <p className="text-sm text-ink-900/45 mt-2">
                  Nothing logged yet — add an expense below.
                </p>
              )}
            </CardContent>
          </Card>

          <Button className="w-full" variant="primary" onClick={() => setShowForm(!showForm)}>
            <Plus className="h-4 w-4" /> {showForm ? "Close" : "Add an expense"}
          </Button>

          <AnimatePresence>
            {showForm && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3, ease: easeOut }}
                className="overflow-hidden"
              >
                <Card>
                  <CardContent className="p-5 space-y-3.5">
                    <div className="grid grid-cols-2 gap-2.5">
                      <div>
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={date}
                          onChange={(e) => setDate(e.target.value)}
                          className="mt-1.5"
                        />
                      </div>
                      <div>
                        <Label>Category</Label>
                        <Select value={category} onValueChange={setCategory}>
                          <SelectTrigger className="mt-1.5">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {CATEGORIES.map((c) => (
                              <SelectItem key={c} value={c}>
                                {c}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label>Description</Label>
                      <Input
                        className="mt-1.5"
                        placeholder="Group dinner at Shambles"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                      />
                    </div>

                    <div>
                      <Label>Merchant</Label>
                      <Input
                        className="mt-1.5"
                        placeholder="Shambles Restaurant"
                        value={merchant}
                        onChange={(e) => setMerchant(e.target.value)}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2.5">
                      <div>
                        <Label>Amount</Label>
                        <Input
                          className="mt-1.5"
                          type="number"
                          placeholder="0.00"
                          value={totalAmount}
                          onChange={(e) => setTotalAmount(e.target.value)}
                        />
                      </div>
                      <div>
                        <Label>Paid by</Label>
                        <Select value={paidBy} onValueChange={setPaidBy}>
                          <SelectTrigger className="mt-1.5">
                            <SelectValue placeholder="Choose..." />
                          </SelectTrigger>
                          <SelectContent>
                            {households.map((h) => (
                              <SelectItem key={h.id} value={String(h.id)}>
                                {h.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label>Split method</Label>
                      <Select value={method} onValueChange={setMethod}>
                        <SelectTrigger className="mt-1.5">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {METHODS.map((m) => (
                            <SelectItem key={m.value} value={m.value}>
                              {m.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {(method === "equal_selected" || method === "percentage" || method === "fixed") && (
                      <div className="space-y-2.5 rounded-2xl bg-sand-50 p-4">
                        {households.map((h) => (
                          <div key={h.id} className="flex items-center gap-2">
                            {method === "equal_selected" ? (
                              <label className="flex items-center gap-2.5 text-sm flex-1">
                                <Checkbox
                                  checked={!!selected[h.id]}
                                  onCheckedChange={(c) => setSelected({ ...selected, [h.id]: !!c })}
                                />
                                {h.name}
                              </label>
                            ) : (
                              <>
                                <span className="text-sm flex-1 text-ink-900/80">{h.name}</span>
                                <Input
                                  type="number"
                                  className="w-24 h-9"
                                  placeholder={method === "percentage" ? "%" : "$"}
                                  value={customShares[h.id] ?? ""}
                                  onChange={(e) =>
                                    setCustomShares({ ...customShares, [h.id]: Number(e.target.value) })
                                  }
                                />
                              </>
                            )}
                          </div>
                        ))}
                        {(method === "percentage" || method === "fixed") && (
                          <p className="text-xs text-ink-900/40 pt-1">
                            Allocated:{" "}
                            {method === "percentage"
                              ? `${Object.values(customShares).reduce((a, b) => a + b, 0)}%`
                              : `$${shareTotal.toFixed(2)} of $${total.toFixed(2)}`}
                          </p>
                        )}
                      </div>
                    )}

                    <div>
                      <Label>Receipt</Label>
                      <div className="mt-1.5">
                        {receiptUrl ? (
                          <div className="relative w-24 h-24">
                            <img
                              src={receiptUrl}
                              className="w-24 h-24 object-cover rounded-2xl border border-ink-900/10"
                            />
                            <button
                              onClick={() => setReceiptUrl("")}
                              className="absolute -top-2 -right-2 bg-ink-900 text-white rounded-full p-1 shadow-card"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ) : (
                          <label className="flex items-center gap-2 justify-center h-24 w-24 rounded-2xl border-2 border-dashed border-ink-900/10 cursor-pointer text-ink-900/35 hover:border-lagoon-500 hover:text-lagoon-600 transition-colors">
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => e.target.files?.[0] && handleReceiptSelect(e.target.files[0])}
                            />
                            {uploading ? (
                              <span className="text-xs">Uploading…</span>
                            ) : (
                              <Camera className="h-6 w-6" />
                            )}
                          </label>
                        )}
                      </div>
                    </div>

                    <div>
                      <Label>Notes</Label>
                      <Textarea
                        className="mt-1.5"
                        placeholder="Optional"
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                      />
                    </div>

                    <Button variant="primary" className="w-full" onClick={submit}>
                      Save expense
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {/* ---- Expense list — receipt-forward, minimal math ---- */}
          <div className="space-y-2">
            {expenses.map((e, i) => (
              <motion.div
                key={e.id}
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ delay: Math.min(i, 6) * 0.03, duration: 0.3 }}
              >
                <Card>
                  <CardContent className="p-3.5 flex items-center gap-3.5">
                    {e.receiptUrl ? (
                      <img
                        src={e.receiptUrl}
                        onClick={() => setLightbox(e.receiptUrl!)}
                        className="h-14 w-14 object-cover rounded-2xl flex-shrink-0 cursor-pointer tap ring-1 ring-ink-900/[0.06]"
                      />
                    ) : (
                      <div className="h-14 w-14 rounded-2xl bg-sand-50 flex items-center justify-center flex-shrink-0">
                        <ReceiptIcon className="h-5 w-5 text-ink-900/15" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-ink-900 text-[15px] truncate">
                        {e.description}
                      </p>
                      <p className="text-xs text-ink-900/40 truncate mt-0.5">
                        {e.merchant || e.category} · {householdName(e.paidByHouseholdId)}
                      </p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="font-display text-lg text-ink-900">
                        ${Number(e.totalAmount).toFixed(0)}
                      </p>
                      <button
                        className="text-[11px] text-ink-900/30 hover:text-papaya-600 font-semibold transition-colors"
                        onClick={() => remove(e.id)}
                      >
                        Remove
                      </button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
            {expenses.length === 0 && (
              <p className="text-sm text-ink-900/40 text-center py-8">No expenses logged yet.</p>
            )}
          </div>
        </div>
      </div>

      <Dialog open={!!lightbox} onOpenChange={(o) => !o && setLightbox(null)}>
        <DialogContent className="p-2 bg-transparent border-none shadow-none max-w-sm">
          {lightbox && <img src={lightbox} className="w-full rounded-2xl" />}
        </DialogContent>
      </Dialog>
    </div>
  );
}
