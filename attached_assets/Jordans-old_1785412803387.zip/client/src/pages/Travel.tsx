import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { PlaneTakeoff, PlaneLanding, Plus } from "lucide-react";
import { api, Guest, Household } from "../lib/api.js";
import { Card, CardContent } from "../components/ui/card.js";
import { Button } from "../components/ui/button.js";
import { Input } from "../components/ui/input.js";
import { Label } from "../components/ui/label.js";
import { Badge } from "../components/ui/badge.js";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "../components/ui/select.js";
import PageHeader from "../components/PageHeader.js";

const STATUS_LABEL: Record<string, { label: string; variant: "lagoon" | "papaya" | "brass" | "outline" }> = {
  on_time: { label: "On time", variant: "lagoon" },
  delayed: { label: "Delayed", variant: "brass" },
  landed: { label: "Landed", variant: "outline" },
  cancelled: { label: "Cancelled", variant: "papaya" },
};

const empty = {
  householdId: "",
  name: "",
  airline: "",
  arrivalDatetime: "",
  arrivalFlightNumber: "",
  arrivalAirport: "",
  departureDatetime: "",
  departureFlightNumber: "",
  departureAirport: "",
  notes: "",
};

export default function Travel() {
  const [guests, setGuests] = useState<Guest[]>([]);
  const [households, setHouseholds] = useState<Household[]>([]);
  const [form, setForm] = useState(empty);
  const [showForm, setShowForm] = useState(false);

  const load = () => {
    api.get("/guests").then(setGuests);
    api.get("/households").then(setHouseholds);
  };
  useEffect(load, []);

  const householdName = (id: number) => households.find((h) => h.id === id)?.name ?? "—";

  const submit = async () => {
    if (!form.name || !form.householdId) return;
    await api.post("/guests", {
      ...form,
      householdId: Number(form.householdId),
      arrivalDatetime: form.arrivalDatetime || null,
      departureDatetime: form.departureDatetime || null,
    });
    setForm(empty);
    setShowForm(false);
    load();
  };

  const remove = async (id: number) => {
    await api.del(`/guests/${id}`);
    load();
  };

  const setStatus = async (id: number, flightStatus: string) => {
    await api.patch(`/guests/${id}`, { flightStatus });
    load();
  };

  const arrivals = [...guests]
    .filter((g) => g.arrivalDatetime)
    .sort((a, b) => (a.arrivalDatetime! < b.arrivalDatetime! ? -1 : 1));
  const departures = [...guests]
    .filter((g) => g.departureDatetime)
    .sort((a, b) => (a.departureDatetime! < b.departureDatetime! ? -1 : 1));

  return (
    <div>
      <PageHeader eyebrow="Getting there" title="Travel" subtitle="Everyone's flights, in one board." />

      <div className="px-5 space-y-6">
        <Button className="w-full" variant="primary" onClick={() => setShowForm(!showForm)}>
          <Plus className="h-4 w-4" /> {showForm ? "Close" : "Add my travel"}
        </Button>

        {showForm && (
          <Card>
            <CardContent className="p-5 space-y-3">
              <Select value={form.householdId} onValueChange={(v) => setForm({ ...form, householdId: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Household..." />
                </SelectTrigger>
                <SelectContent>
                  {households.map((h) => (
                    <SelectItem key={h.id} value={String(h.id)}>
                      {h.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="Your name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <Label>Arrival</Label>
                  <Input
                    type="datetime-local"
                    className="mt-1"
                    value={form.arrivalDatetime}
                    onChange={(e) => setForm({ ...form, arrivalDatetime: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Departure</Label>
                  <Input
                    type="datetime-local"
                    className="mt-1"
                    value={form.departureDatetime}
                    onChange={(e) => setForm({ ...form, departureDatetime: e.target.value })}
                  />
                </div>
              </div>
              <Input
                placeholder="Airline (e.g. Delta, JetBlue)"
                value={form.airline}
                onChange={(e) => setForm({ ...form, airline: e.target.value })}
              />
              <div className="grid grid-cols-2 gap-2.5">
                <Input
                  placeholder="Arrival flight #"
                  value={form.arrivalFlightNumber}
                  onChange={(e) => setForm({ ...form, arrivalFlightNumber: e.target.value })}
                />
                <Input
                  placeholder="Departure flight #"
                  value={form.departureFlightNumber}
                  onChange={(e) => setForm({ ...form, departureFlightNumber: e.target.value })}
                />
              </div>
              <Input
                placeholder="Notes (rental car, ride needed, etc.)"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
              <Button variant="primary" className="w-full" onClick={submit}>
                Save
              </Button>
            </CardContent>
          </Card>
        )}

        <div>
          <div className="flex items-center gap-2 mb-3">
            <PlaneLanding className="h-4 w-4 text-lagoon-600" />
            <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em]">Arrivals</p>
          </div>
          <div className="space-y-2.5">
            {arrivals.map((g, i) => (
              <motion.div
                key={g.id}
                initial={{ opacity: 0, x: -8 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.04 }}
              >
                <Card>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold text-ink-900 text-sm">{g.name}</p>
                        <p className="text-xs text-ink-900/50">{householdName(g.householdId)}</p>
                      </div>
                      <button className="text-[11px] text-ink-900/30 hover:text-papaya-600 font-semibold transition-colors" onClick={() => remove(g.id)}>
                        Remove
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-2.5">
                      <div className="text-sm text-ink-900/70">
                        {new Date(g.arrivalDatetime!).toLocaleString(undefined, {
                          weekday: "short",
                          month: "short",
                          day: "numeric",
                          hour: "numeric",
                          minute: "2-digit",
                        })}
                        {(g.airline || g.arrivalFlightNumber) && (
                          <span className="text-ink-900/40">
                            {" "}
                            · {[g.airline, g.arrivalFlightNumber].filter(Boolean).join(" ")}
                          </span>
                        )}
                      </div>
                      <Select value={g.flightStatus ?? "on_time"} onValueChange={(v) => setStatus(g.id, v)}>
                        <SelectTrigger className="h-7 w-auto px-2 border-none bg-transparent">
                          <Badge variant={STATUS_LABEL[g.flightStatus ?? "on_time"].variant}>
                            {STATUS_LABEL[g.flightStatus ?? "on_time"].label}
                          </Badge>
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(STATUS_LABEL).map(([k, v]) => (
                            <SelectItem key={k} value={k}>
                              {v.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
            {arrivals.length === 0 && (
              <p className="text-sm text-ink-900/40 text-center py-4">No arrivals logged yet.</p>
            )}
          </div>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-3">
            <PlaneTakeoff className="h-4 w-4 text-papaya-500" />
            <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em]">Departures</p>
          </div>
          <div className="space-y-2.5">
            {departures.map((g) => (
              <Card key={g.id}>
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-ink-900 text-sm">{g.name}</p>
                    <p className="text-xs text-ink-900/50">{householdName(g.householdId)}</p>
                  </div>
                  <div className="text-right text-sm text-ink-900/70">
                    {new Date(g.departureDatetime!).toLocaleString(undefined, {
                      month: "short",
                      day: "numeric",
                      hour: "numeric",
                      minute: "2-digit",
                    })}
                    {(g.airline || g.departureFlightNumber) && (
                      <p className="text-xs text-ink-900/40">
                        {[g.airline, g.departureFlightNumber].filter(Boolean).join(" ")}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
            {departures.length === 0 && (
              <p className="text-sm text-ink-900/40 text-center py-4">No departures logged yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
