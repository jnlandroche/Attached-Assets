import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Plus, Plane, UtensilsCrossed, Waves, Sparkles, Circle } from "lucide-react";
import { api, ItineraryItem } from "../lib/api.js";
import { Card, CardContent } from "../components/ui/card.js";
import { Button } from "../components/ui/button.js";
import { Input } from "../components/ui/input.js";
import { Textarea } from "../components/ui/textarea.js";
import PageHeader from "../components/PageHeader.js";

const CATEGORY_ICON: Record<string, typeof Plane> = {
  arrival: Plane,
  food: UtensilsCrossed,
  beach: Waves,
  activity: Sparkles,
  general: Circle,
};

const CATEGORY_COLOR: Record<string, string> = {
  arrival: "bg-ink-700",
  food: "bg-papaya-500",
  beach: "bg-lagoon-400",
  activity: "bg-brass-500",
  general: "bg-ink-900/30",
};

const empty = { dayLabel: "", time: "", title: "", description: "", category: "general" };

export default function Weekend() {
  const [items, setItems] = useState<ItineraryItem[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(empty);

  const load = () => {
    api.get("/itinerary").then(setItems);
  };
  useEffect(load, []);

  const submit = async () => {
    if (!form.title || !form.dayLabel) return;
    await api.post("/itinerary", { ...form, sortOrder: items.length + 1 });
    setForm(empty);
    setShowForm(false);
    load();
  };

  const remove = async (id: number) => {
    await api.del(`/itinerary/${id}`);
    load();
  };

  const days = Array.from(new Set(items.map((i) => i.dayLabel)));

  return (
    <div>
      <PageHeader eyebrow="The plan" title="Weekend" subtitle="A flexible timeline, not a fixed schedule." />

      <div className="px-5 space-y-6">
        <Button className="w-full" variant="primary" onClick={() => setShowForm(!showForm)}>
          <Plus className="h-4 w-4" /> {showForm ? "Close" : "Add to the timeline"}
        </Button>

        {showForm && (
          <Card>
            <CardContent className="p-5 space-y-3">
              <Input
                placeholder="Day label (e.g. Day 2)"
                value={form.dayLabel}
                onChange={(e) => setForm({ ...form, dayLabel: e.target.value })}
              />
              <Input
                placeholder="Time (e.g. Afternoon, 3:00 PM)"
                value={form.time}
                onChange={(e) => setForm({ ...form, time: e.target.value })}
              />
              <Input
                placeholder="Title"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
              <Textarea
                placeholder="Description (optional)"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
              <Button variant="primary" className="w-full" onClick={submit}>
                Add
              </Button>
            </CardContent>
          </Card>
        )}

        {days.map((day) => (
          <div key={day}>
            <p className="text-[11px] font-bold text-ink-900/35 uppercase tracking-[0.1em] mb-3">{day}</p>
            <div className="relative pl-6 space-y-4 border-l-2 border-sand-200">
              {items
                .filter((i) => i.dayLabel === day)
                .map((item, idx) => {
                  const Icon = CATEGORY_ICON[item.category ?? "general"] ?? Circle;
                  const color = CATEGORY_COLOR[item.category ?? "general"];
                  return (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, x: -8 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.05 }}
                      className="relative"
                    >
                      <div
                        className={`absolute -left-[1.85rem] top-0.5 h-5 w-5 rounded-full ${color} flex items-center justify-center`}
                      >
                        <Icon className="h-3 w-3 text-white" />
                      </div>
                      <Card>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              {item.time && (
                                <p className="text-xs font-bold text-ink-900/40 uppercase">{item.time}</p>
                              )}
                              <p className="font-semibold text-ink-900 text-sm mt-0.5">{item.title}</p>
                              {item.description && (
                                <p className="text-sm text-ink-900/60 mt-1">{item.description}</p>
                              )}
                            </div>
                            <button
                              className="text-[11px] text-ink-900/30 hover:text-papaya-600 font-semibold transition-colors flex-shrink-0"
                              onClick={() => remove(item.id)}
                            >
                              Remove
                            </button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
            </div>
          </div>
        ))}

        {items.length === 0 && (
          <p className="text-sm text-ink-900/40 text-center py-8">Nothing planned yet.</p>
        )}
      </div>
    </div>
  );
}
