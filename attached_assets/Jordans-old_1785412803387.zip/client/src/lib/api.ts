const BASE = "/api";

async function request(path: string, options: RequestInit = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: options.body instanceof FormData ? undefined : { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) throw new Error(`Request failed: ${path}`);
  return res.json();
}

export const api = {
  get: (path: string) => request(path),
  post: (path: string, body: unknown) =>
    request(path, { method: "POST", body: JSON.stringify(body) }),
  patch: (path: string, body: unknown) =>
    request(path, { method: "PATCH", body: JSON.stringify(body) }),
  del: (path: string) => request(path, { method: "DELETE" }),
  upload: (path: string, formData: FormData) =>
    request(path, { method: "POST", body: formData }),
};

export type Household = {
  id: number;
  name: string;
  photoUrl?: string;
  phone?: string;
  email?: string;
  notes?: string;
  sortOrder?: number;
};

export type Guest = {
  id: number;
  householdId: number;
  name: string;
  arrivalDatetime?: string;
  airline?: string;
  arrivalFlightNumber?: string;
  arrivalAirport?: string;
  departureDatetime?: string;
  departureFlightNumber?: string;
  departureAirport?: string;
  rentalCarInfo?: string;
  transportationNeeds?: string;
  flightStatus?: "on_time" | "delayed" | "landed" | "cancelled";
  notes?: string;
};

export type Room = {
  id: number;
  name: string;
  bedConfig?: string;
  bathLayout?: string;
  occupancy?: number;
  photoUrl?: string;
  notes?: string;
  assignedHouseholdId?: number | null;
  sortOrder?: number;
};

export type ExpenseShare = { householdId: number; shareAmount: number };

export type Expense = {
  id: number;
  date: string;
  description: string;
  category: string;
  merchant?: string;
  paidByHouseholdId: number | null;
  totalAmount: number;
  allocationMethod: string;
  participantHouseholdIds: number[];
  receiptUrl?: string;
  notes?: string;
  shares: ExpenseShare[];
};

export type Balance = {
  householdId: number;
  householdName: string;
  totalPaid: number;
  totalShare: number;
  netBalance: number;
};

export type SettlementRecommendation = {
  fromHouseholdId: number;
  fromName: string;
  toHouseholdId: number;
  toName: string;
  amount: number;
};

export type Settlement = {
  id: number;
  fromHouseholdId: number;
  toHouseholdId: number;
  amount: number;
  status: "pending" | "paid";
  createdAt: string;
  paidAt?: string;
};

export type GuideEntry = {
  id: number;
  type: "dining" | "bar" | "activity" | "beach" | "coffee" | "grocery" | "boat";
  name: string;
  subtitle?: string;
  priceTier?: string;
  distanceFromVilla?: string;
  notes?: string;
  photoUrl?: string;
  mapUrl?: string;
  reservationStatus?: string;
  websiteUrl?: string;
  favorited?: boolean;
  sortOrder?: number;
};

export type Contact = {
  id: number;
  category: string;
  name: string;
  phone?: string;
  address?: string;
  notes?: string;
  sortOrder?: number;
};

export type ItineraryItem = {
  id: number;
  dayLabel: string;
  time?: string;
  title: string;
  description?: string;
  category?: string;
  sortOrder?: number;
};
