import {
  pgTable,
  serial,
  text,
  integer,
  numeric,
  date,
  timestamp,
  boolean,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------
// Households (couples) attending the trip
// ---------------------------------------------------------------------
export const households = pgTable("households", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(), // e.g. "Jordan & Danielle"
  photoUrl: text("photo_url"),
  phone: text("phone"),
  email: text("email"),
  notes: text("notes"), // dietary restrictions, etc.
  sortOrder: integer("sort_order").default(0),
});

// ---------------------------------------------------------------------
// Individual guests within a household (for the travel scheduler)
// ---------------------------------------------------------------------
export const guests = pgTable("guests", {
  id: serial("id").primaryKey(),
  householdId: integer("household_id").references(() => households.id, {
    onDelete: "cascade",
  }),
  name: text("name").notNull(),
  arrivalDatetime: timestamp("arrival_datetime", { mode: "string" }),
  airline: text("airline"),
  arrivalFlightNumber: text("arrival_flight_number"),
  arrivalAirport: text("arrival_airport"),
  departureDatetime: timestamp("departure_datetime", { mode: "string" }),
  departureFlightNumber: text("departure_flight_number"),
  departureAirport: text("departure_airport"),
  rentalCarInfo: text("rental_car_info"),
  transportationNeeds: text("transportation_needs"),
  flightStatus: text("flight_status").default("on_time"), // on_time | delayed | landed | cancelled
  notes: text("notes"),
});

// ---------------------------------------------------------------------
// Weekend itinerary — a timeline of the trip, fully editable
// ---------------------------------------------------------------------
export const itineraryItems = pgTable("itinerary_items", {
  id: serial("id").primaryKey(),
  dayLabel: text("day_label").notNull(), // "Friday 8/14", "Saturday 8/15"
  time: text("time"), // "3:00 PM"
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").default("general"), // arrival | food | activity | beach | general
  sortOrder: integer("sort_order").default(0),
});

// ---------------------------------------------------------------------
// Rooms at the villa
// ---------------------------------------------------------------------
export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  bedConfig: text("bed_config"),
  bathLayout: text("bath_layout"),
  occupancy: integer("occupancy"),
  photoUrl: text("photo_url"),
  notes: text("notes"),
  assignedHouseholdId: integer("assigned_household_id").references(
    () => households.id,
    { onDelete: "set null" }
  ),
  sortOrder: integer("sort_order").default(0),
});

// ---------------------------------------------------------------------
// Expenses
// ---------------------------------------------------------------------
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // Lodging / Food & Drink / Groceries / Transportation / Activities / Entertainment / Other
  merchant: text("merchant"),
  paidByHouseholdId: integer("paid_by_household_id")
    .references(() => households.id, { onDelete: "set null" }),
  totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).notNull(),
  allocationMethod: text("allocation_method").notNull(), // equal_all | equal_selected | percentage | fixed | single_payer
  participantHouseholdIds: text("participant_household_ids"), // JSON array of household ids who took part
  receiptUrl: text("receipt_url"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Resolved per-household share for each expense (stored at write time so
// balances are just a SUM, regardless of which allocation method was used).
export const expenseShares = pgTable("expense_shares", {
  id: serial("id").primaryKey(),
  expenseId: integer("expense_id")
    .references(() => expenses.id, { onDelete: "cascade" })
    .notNull(),
  householdId: integer("household_id")
    .references(() => households.id, { onDelete: "cascade" })
    .notNull(),
  shareAmount: numeric("share_amount", { precision: 10, scale: 2 }).notNull(),
});

// Actual settlement payments between households (recorded when someone
// checks off a settlement recommendation as paid). These feed back into
// the balance calculation so recommendations shrink as debts get settled.
export const settlements = pgTable("settlements", {
  id: serial("id").primaryKey(),
  fromHouseholdId: integer("from_household_id")
    .references(() => households.id, { onDelete: "cascade" })
    .notNull(),
  toHouseholdId: integer("to_household_id")
    .references(() => households.id, { onDelete: "cascade" })
    .notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"), // pending | paid
  createdAt: timestamp("created_at").defaultNow(),
  paidAt: timestamp("paid_at"),
});

// ---------------------------------------------------------------------
// Local guide (dining / bars / activities / beaches), one table + a
// "type" column so the UI can filter into sub-tabs without four schemas.
// ---------------------------------------------------------------------
export const guideEntries = pgTable("guide_entries", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // dining | bar | activity | beach
  name: text("name").notNull(),
  subtitle: text("subtitle"), // cuisine/type, region, time needed, etc.
  priceTier: text("price_tier"), // $ / $$ / $$$
  distanceFromVilla: text("distance_from_villa"),
  notes: text("notes"),
  photoUrl: text("photo_url"),
  mapUrl: text("map_url"),
  reservationStatus: text("reservation_status"), // e.g. "Booked 7pm 8/14", "Walk-in"
  websiteUrl: text("website_url"),
  favorited: boolean("favorited").default(false),
  sortOrder: integer("sort_order").default(0),
});

// ---------------------------------------------------------------------
// Important contacts
// ---------------------------------------------------------------------
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(), // host | taxi | hospital | urgent_care | pharmacy | police | grocery | other
  name: text("name").notNull(),
  phone: text("phone"),
  address: text("address"),
  notes: text("notes"),
  sortOrder: integer("sort_order").default(0),
});

// ---------------------------------------------------------------------
// A few site-wide settings (trip dates, property name, hero photo, etc.)
// stored as simple key/value so the homepage never needs a migration
// to change a date or swap a photo.
// ---------------------------------------------------------------------
export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value"),
});
