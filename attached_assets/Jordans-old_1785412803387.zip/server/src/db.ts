import "dotenv/config";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "./schema.js";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL is not set. On Replit: Tools > Database to provision Postgres, " +
      "then add the connection string as a Secret named DATABASE_URL."
  );
}

const client = postgres(process.env.DATABASE_URL, { max: 5 });
export const db = drizzle(client, { schema });
