import { db } from "./db.js";
import {
  households,
  rooms,
  guideEntries,
  contacts,
  settings,
  itineraryItems,
} from "./schema.js";

async function seed() {
  console.log("Seeding database...");

  // -------------------------------------------------------------
  // Settings (safe to edit anytime — just key/value, no migration)
  // -------------------------------------------------------------
  await db
    .insert(settings)
    .values([
      { key: "trip_title", value: "Jordan's 40th — St. John, USVI" },
      { key: "property_name", value: "Terrapin Station (fka Stella Bella)" },
      { key: "property_location", value: "Chocolate Hole, St. John, USVI" },
      { key: "vrbo_url", value: "https://www.vrbo.com/2090694" },
      { key: "guest_rating", value: "9.6 / 10 — Exceptional (82 reviews)" },
      { key: "check_in_date", value: "" }, // fill in once dates are locked
      { key: "check_out_date", value: "" },
      { key: "weather_summary", value: "Upper 80s°F, brief tropical showers possible — typical Caribbean summer" },
      { key: "announcement", value: "Add a note here for the group — packing reminders, dinner plans, anything else." },
      { key: "target_budget", value: "" },
      { key: "hero_photo", value: "/images/group-formal.jpg" },
      {
        key: "villa_gallery",
        value: JSON.stringify([
          "https://media.vrbo.com/lodging/60000000/59240000/59236700/59236603/567949bb.jpg?impolicy=resizecrop&rw=1200&ra=fit",
          "https://media.vrbo.com/lodging/60000000/59240000/59236700/59236603/a0784551.jpg?impolicy=resizecrop&rw=1200&ra=fit",
          "https://media.vrbo.com/lodging/60000000/59240000/59236700/59236603/82e7684c.jpg?impolicy=resizecrop&rw=1200&ra=fit",
          "https://media.vrbo.com/lodging/60000000/59240000/59236700/59236603/b2170c33.jpg?impolicy=resizecrop&rw=1200&ra=fit",
          "https://media.vrbo.com/lodging/60000000/59240000/59236700/59236603/6854944b.jpg?impolicy=resizecrop&rw=1200&ra=fit",
        ]),
      },
      { key: "check_in_time", value: "" },
      { key: "check_out_time", value: "" },
      { key: "house_rules", value: "" },
      {
        key: "birthday_photos",
        value: JSON.stringify([
          "/images/jordan-wine.jpg",
          "/images/jordan-sunset-couple.jpg",
          "/images/jordan-boat.jpg",
          "/images/jordan-fishing-lake.jpg",
          "/images/jordan-fish-catch.jpg",
        ]),
      },
      {
        key: "group_photos",
        value: JSON.stringify([
          "/images/group-formal.jpg",
          "/images/group-stadium.jpg",
          "/images/group-tailgate.jpg",
        ]),
      },
    ])
    .onConflictDoNothing();

  // -------------------------------------------------------------
  // Households — edit names here, everything else follows
  // -------------------------------------------------------------
  const householdRows = await db
    .insert(households)
    .values([
      { name: "Jordan & Danielle", sortOrder: 1 },
      { name: "Justin & Allison", sortOrder: 2 },
      { name: "Eric & Rachel", sortOrder: 3 },
      { name: "Jeff & Keri", sortOrder: 4 },
    ])
    .returning();

  const byName = Object.fromEntries(householdRows.map((h) => [h.name, h.id]));

  // -------------------------------------------------------------
  // Rooms — matches the villa's actual 4-bedroom layout. Photos are the
  // real listing images from vrbo.com/2090694, used only where the
  // listing's own photo caption confirms which room it shows. The two
  // rooms without a confirmed matching photo are left blank rather than
  // guessing — see photoUrl: null below.
  // -------------------------------------------------------------
  await db.insert(rooms).values([
    {
      name: "Primary Suite 1 (Upstairs, East)",
      bedConfig: "King bed + separate day bed",
      bathLayout:
        "Private en-suite bath, 350+ sf, large covered screened-in porch, ocean & Chocolate Hole/Hart Bay views",
      occupancy: 2,
      photoUrl:
        "https://media.vrbo.com/lodging/60000000/59240000/59236700/59236603/59dd6e48.jpg?impolicy=resizecrop&rw=900&ra=fit",
      notes: "Listing photo caption: \"Looking toward Entrance & East Primary BR.\"",
      assignedHouseholdId: byName["Jordan & Danielle"],
      sortOrder: 1,
    },
    {
      name: "Primary Suite 2 (Upstairs, West)",
      bedConfig: "King bed + separate day bed",
      bathLayout:
        "Private en-suite bath, 350+ sf, large covered screened-in porch, same panoramic views",
      occupancy: 2,
      photoUrl: null,
      notes: "No confirmed listing photo of this specific room — add one once you're there, or from the VRBO gallery.",
      assignedHouseholdId: byName["Justin & Allison"],
      sortOrder: 2,
    },
    {
      name: "Bedroom 3 (Downstairs, mini-apartment)",
      bedConfig:
        "King bed in one room + space for a full-size air mattress in the separate living area",
      bathLayout: "Private bath, kitchenette, separate entrance",
      occupancy: 3,
      photoUrl:
        "https://media.vrbo.com/lodging/60000000/59240000/59236700/59236603/f49c41f0.jpg?impolicy=resizecrop&rw=900&ra=fit",
      notes: "Listing photo caption: \"West Apartment - Deck of Bedroom #3.\"",
      assignedHouseholdId: byName["Eric & Rachel"],
      sortOrder: 3,
    },
    {
      name: "Bedroom 4 (Downstairs, efficiency)",
      bedConfig: "Queen bed",
      bathLayout: "Private bath, full kitchen, separate entrance",
      occupancy: 2,
      photoUrl: null,
      notes: "No confirmed listing photo of this specific room — add one once you're there, or from the VRBO gallery.",
      assignedHouseholdId: byName["Jeff & Keri"],
      sortOrder: 4,
    },
  ]);

  // -------------------------------------------------------------
  // Local guide — dining / bars / activities / beaches
  // -------------------------------------------------------------
  // Real, verified official websites where I could confirm one via search.
  // Left blank (not guessed) for places I couldn't verify — better an
  // editable blank than a wrong or fabricated link.
  const WEBSITES: Record<string, string> = {
    "Shambles": "https://www.shamblesvi.com",
    "The Longboard": "https://www.thelongboardstjohn.com",
    "Cruz Bay Landing": "https://www.cruzbaylanding.com",
    "Morgan's Mango": "https://www.morgansmango.com",
    "La Tapa": "https://www.latapastjohn.com",
    "Lime Inn": "https://www.limeoutvi.com/lime-inn",
    "High Tide Bar & Grill": "https://www.hightidestjohn.com",
    "Sun Dog Café": "https://www.sundogcafe.com",
    "Lime Out": "https://www.limeoutvi.com",
    "The Tap Room (Mongoose Junction)": "https://www.stjohnbrewers.com",
    "Ocean Runner Powerboat Rentals": "https://oceanrunnerusvi.com",
    "Wharfside Watersports": "https://wharfsidewatersports.com",
    "Palm Tree Charters": "https://palmtreecharters.com",
  };

  function withGuideExtras(row: any) {
    return {
      ...row,
      websiteUrl: WEBSITES[row.name as string] ?? null,
      mapUrl: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
        row.name + ", St. John, USVI"
      )}`,
      favorited: false,
    };
  }

  const guideRows = [
    // Dining
    { type: "dining", name: "Shambles", subtitle: "Upscale / New American", priceTier: "$$$", distanceFromVilla: "9 min drive", notes: "Closest fine-dining pick to the villa.", sortOrder: 1 },
    { type: "dining", name: "Woody's Seafood Saloon", subtitle: "Seafood / Casual", priceTier: "$$", distanceFromVilla: "7 min drive", notes: "Lively, good raw bar, popular with locals. (340) 779-4625.", sortOrder: 2 },
    { type: "dining", name: "The Longboard", subtitle: "Coastal / Cocktail kitchen", priceTier: "$$", distanceFromVilla: "7 min drive", notes: "Creative cocktails, ceviche, shrimp tostones, poke bowl.", sortOrder: 3 },
    { type: "dining", name: "Cruz Bay Landing", subtitle: "American / Caribbean", priceTier: "$$", distanceFromVilla: "7 min drive", notes: "Across from the ferry dock; seared scallops, Mahi Mahi, live music.", sortOrder: 4 },
    { type: "dining", name: "Morgan's Mango", subtitle: "Caribbean / Seafood", priceTier: "$$$", distanceFromVilla: "7 min drive", notes: "Long-running Cruz Bay favorite. (340) 693-8141.", sortOrder: 5 },
    { type: "dining", name: "La Tapa", subtitle: "Spanish / Tapas", priceTier: "$$$", distanceFromVilla: "~10-12 min drive", notes: "USA Today top-10 USVI pick. Reservation recommended. (340) 693-7755.", sortOrder: 6 },
    { type: "dining", name: "Lime Inn", subtitle: "Caribbean coastal", priceTier: "$$$", distanceFromVilla: "~10-12 min drive", notes: "Tasting menu ~$85/pp. Reservation recommended.", sortOrder: 7 },
    { type: "dining", name: "Extra Virgin Bistro", subtitle: "French-inspired", priceTier: "$$$", distanceFromVilla: "~10-12 min drive", notes: "Classy waterside date-night option. (340) 715-1864.", sortOrder: 8 },
    { type: "dining", name: "High Tide Bar & Grill", subtitle: "American / Beachfront", priceTier: "$$", distanceFromVilla: "~10-12 min drive", notes: "On Cruz Bay Beach; live music at sunset.", sortOrder: 9 },
    { type: "dining", name: "Sun Dog Café", subtitle: "Casual / Alfresco", priceTier: "$", distanceFromVilla: "~10-12 min drive", notes: "Mongoose Junction; salads, sandwiches, pizza.", sortOrder: 10 },
    { type: "dining", name: "Skinny Legs Bar & Grill", subtitle: "American / Dive bar", priceTier: "$$", distanceFromVilla: "~30 min drive (Coral Bay)", notes: "Five-star laid-back East End institution. (340) 779-4982.", sortOrder: 11 },
    { type: "dining", name: "Lime Out", subtitle: "Floating taco & tiki bar", priceTier: "$$", distanceFromVilla: "Boat/water-taxi access", notes: "Famous shrimp tacos; book ahead, pair with a snorkel tour.", sortOrder: 12 },

    // Bars & hot spots
    { type: "bar", name: "The Longboard", subtitle: "Cocktail bar", distanceFromVilla: "7 min drive", notes: "Craft cocktails, a Cruz Bay favorite.", sortOrder: 1 },
    { type: "bar", name: "Woody's Seafood Saloon", subtitle: "Sports bar", distanceFromVilla: "7 min drive", notes: "Loud, fun, big screens. Happy hour daily 3-7pm.", sortOrder: 2 },
    { type: "bar", name: "High Tide Bar & Grill", subtitle: "Beach bar", distanceFromVilla: "~10-12 min drive", notes: "Live music, sunset views over the harbor.", sortOrder: 3 },
    { type: "bar", name: "Cruz Bay Landing", subtitle: "Waterfront bar", distanceFromVilla: "7 min drive", notes: "Live music most nights, across from the ferry dock.", sortOrder: 4 },
    { type: "bar", name: "The Tap Room (Mongoose Junction)", subtitle: "Brewery taproom", distanceFromVilla: "~10-12 min drive", notes: "St. John Brewers beer, open til ~11pm.", sortOrder: 5 },
    { type: "bar", name: "Bajo El Sol Gallery, Art Bar & Rum Room", subtitle: "Rum bar / Gallery", distanceFromVilla: "~10-12 min drive", notes: "Rum flights inside an art gallery.", sortOrder: 6 },
    { type: "bar", name: "The Blind Donkey", subtitle: "New pub", distanceFromVilla: "~10-12 min drive", notes: "Opened in the old Quiet Mon Pub space.", sortOrder: 7 },
    { type: "bar", name: "Skinny Legs Bar & Grill", subtitle: "Dive bar", distanceFromVilla: "~30 min drive (Coral Bay)", notes: "Laid-back East End institution.", sortOrder: 8 },

    // Activities / things to do
    { type: "activity", name: "Trunk Bay snorkel trail", subtitle: "Beach / Snorkel · Half day", notes: "National Park entrance fee (~$5pp); self-guided underwater trail. Arrive early.", sortOrder: 1 },
    { type: "activity", name: "Reef Bay Trail hike", subtitle: "Hike · Half day", notes: "Most popular hike in the National Park; plantation ruins and petroglyphs.", sortOrder: 2 },
    { type: "activity", name: "Ram Head Trail", subtitle: "Hike · 2-3 hrs", notes: "Coastal out-and-back from Salt Pond Bay; dramatic cliff views.", sortOrder: 3 },
    { type: "activity", name: "Annaberg Plantation Ruins", subtitle: "History · 1-2 hrs", notes: "18th-century sugar plantation ruins on the North Shore.", sortOrder: 4 },
    { type: "activity", name: "Boat / catamaran charter", subtitle: "Boating · Half or full day", notes: "Depart from Cruz Bay; island-hopping, snorkeling stops.", sortOrder: 5 },
    { type: "activity", name: "Snorkel Watermelon Cay", subtitle: "Snorkel · Half day", notes: "Turtles, rays, coral — a top island pick.", sortOrder: 6 },
    { type: "activity", name: "Kayak / paddleboard Maho or Cinnamon Bay", subtitle: "Water sports · 2-3 hrs", notes: "Rentals on the beach; Maho known for sea turtles.", sortOrder: 7 },
    { type: "activity", name: "Jeep tour of the island", subtitle: "Driving / Scenic · Half day", notes: "Bordeaux Mountain overlook and Coral Bay worth the stop.", sortOrder: 8 },
    { type: "activity", name: "Mongoose Junction shopping", subtitle: "Shopping · 1-2 hrs", notes: "Boutiques, galleries, and the Tap Room in Cruz Bay.", sortOrder: 9 },
    { type: "activity", name: "Rum tasting at Bajo El Sol", subtitle: "Food & Drink · 1 hr", notes: "Flight of local Caribbean rums inside an art gallery.", sortOrder: 10 },
    { type: "activity", name: "Lime Out floating taco bar", subtitle: "Food & Drink · Half day", notes: "Boat/water-taxi access near Coral Bay.", sortOrder: 11 },

    // Beaches
    { type: "beach", name: "Chocolate Hole Beach", subtitle: "South Shore", distanceFromVilla: "3 min drive", notes: "Closest beach to the villa; calm water, best for snorkeling.", sortOrder: 1 },
    { type: "beach", name: "Rendezvous Bay", subtitle: "South Shore", distanceFromVilla: "~1 min drive", notes: "Quiet, low-key, right down the road.", sortOrder: 2 },
    { type: "beach", name: "Hawksnest Beach", subtitle: "North Shore", distanceFromVilla: "~20 min drive", notes: "Closest North Shore beach to Cruz Bay; can be crowded.", sortOrder: 3 },
    { type: "beach", name: "Trunk Bay", subtitle: "North Shore", distanceFromVilla: "~20 min drive", notes: "St. John's most famous beach; underwater snorkel trail, ~$5pp entrance fee.", sortOrder: 4 },
    { type: "beach", name: "Cinnamon Bay", subtitle: "North Shore", distanceFromVilla: "~20-25 min drive", notes: "Island's longest beach; watersport rentals.", sortOrder: 5 },
    { type: "beach", name: "Maho Bay", subtitle: "North Shore", distanceFromVilla: "~25 min drive", notes: "Shallow, calm; best bet for swimming with sea turtles.", sortOrder: 6 },
    { type: "beach", name: "Honeymoon Beach", subtitle: "Near Cruz Bay", distanceFromVilla: "~15 min drive + short walk", notes: "Reached via Lind Point Trail; quieter than Trunk.", sortOrder: 7 },
    { type: "beach", name: "Salt Pond Bay", subtitle: "East End", distanceFromVilla: "~35-40 min drive", notes: "Remote, tranquil; trailhead for Ram Head.", sortOrder: 8 },

    // Coffee
    { type: "coffee", name: "Artisan Gelato Coffee Shop", subtitle: "Coffee & gelato", distanceFromVilla: "~10-12 min drive", notes: "Inside The Marketplace, Cruz Bay. Open Mon-Fri 6am-3pm, Sat 6am-12pm.", sortOrder: 1 },
    { type: "coffee", name: "Sun Dog Café", subtitle: "Casual breakfast & coffee", distanceFromVilla: "~10-12 min drive", notes: "Mongoose Junction; good spot for coffee before a ferry or a hike.", sortOrder: 2 },

    // Groceries
    { type: "grocery", name: "Starfish Market", subtitle: "Full-service grocery", distanceFromVilla: "~10-12 min drive", notes: "The island's largest grocery store, in The Marketplace, Cruz Bay. Full deli, bakery, wine & spirits. Open daily ~7:30am-9pm.", sortOrder: 1 },
    { type: "grocery", name: "Dolphin Market", subtitle: "Neighborhood grocery", distanceFromVilla: "~10-12 min drive", notes: "Boulon Center, Cruz Bay. Good produce and meat selection, smaller than Starfish.", sortOrder: 2 },

    // Boat rentals / charters
    { type: "boat", name: "Ocean Runner Powerboat Rentals", subtitle: "Self-drive & captained charters", distanceFromVilla: "~10-12 min drive (Cruz Bay)", notes: "Boston Whalers and larger charter boats; North Shore runs to Waterlemon Cay.", sortOrder: 1 },
    { type: "boat", name: "Wharfside Watersports", subtitle: "Dinghy & powerboat rentals", distanceFromVilla: "~10-12 min drive (Cruz Bay)", notes: "Dinghy, Zodiac, and larger powerboat rentals right in Cruz Bay.", sortOrder: 2 },
    { type: "boat", name: "Palm Tree Charters", subtitle: "Captained private charters", distanceFromVilla: "~10-12 min drive (Cruz Bay)", notes: "Custom private charters out of Cruz Bay if you'd rather not captain yourselves.", sortOrder: 3 },
  ];

  await db.insert(guideEntries).values(guideRows.map(withGuideExtras));

  // -------------------------------------------------------------
  // Contacts — real numbers, verified via web search
  // -------------------------------------------------------------
  await db.insert(contacts).values([
    { category: "emergency", name: "Emergency (Police / Fire / Ambulance)", phone: "911", notes: "Islandwide emergency line.", sortOrder: 1 },
    { category: "emergency", name: "St. John Rescue", phone: "(340) 776-9110", notes: "All-volunteer rescue org supporting St. John fire & police.", sortOrder: 2 },
    { category: "hospital", name: "Myrah Keating Smith Community Health Center", phone: "(340) 693-8900", address: "Centerline Rd at Gift Hill / Susannaberg, St. John", notes: "24-hr emergency care on St. John. Serious cases are transferred by boat to St. Thomas.", sortOrder: 1 },
    { category: "hospital", name: "Roy Lester Schneider Hospital", phone: "(340) 776-8311", address: "9048 Sugar Estate, St. Thomas, VI 00802", notes: "Main hospital for the USVI; 24-hr ER. Reached by ferry/boat from St. John.", sortOrder: 2 },
    { category: "urgent_care", name: "Island Health & Wellness Center", phone: "(340) 714-4270", address: "Greenleaf Commons, above St. John Market, near Cruz Bay", notes: "Appointment only, flat $50/visit.", sortOrder: 1 },
    { category: "urgent_care", name: "Cruz Bay Family Practice", phone: "(340) 776-6789", address: "Cruz Bay", notes: "Dr. James Clayton; call ahead for urgent same-day issues.", sortOrder: 2 },
    { category: "pharmacy", name: "Chelsea Drug Store", phone: "(340) 776-4888", address: "The Marketplace, Cruz Bay", notes: "Full-service pharmacy; call ahead for specific medications.", sortOrder: 1 },
    { category: "taxi", name: "Paradise Taxi Association", phone: "(340) 714-7913", notes: "Dispatch, 7am-1am daily.", sortOrder: 1 },
    { category: "taxi", name: "Owen (Coral Bay taxi / island tours)", phone: "(340) 626-6274", notes: "Call or text; good for Coral Bay pickups, arrange roundtrip in advance.", sortOrder: 2 },
    { category: "taxi", name: "Dolphin Water Taxi", phone: "(340) 774-2628", notes: "Water transport to St. Thomas / BVI.", sortOrder: 3 },
    { category: "other", name: "VI Taxi Commission (rates/info)", phone: "(340) 693-4211", notes: "Reference for official taxi rates.", sortOrder: 1 },
    { category: "host", name: "Property Host / Property Manager", phone: "", notes: "Add the host's direct contact once confirmed for check-in coordination.", sortOrder: 1 },
  ]);

  // -------------------------------------------------------------
  // Weekend itinerary — a starting skeleton, fully editable in the UI.
  // Built from real, verified places already in the guide above —
  // not reservations, just a sensible flexible plan to adjust.
  // -------------------------------------------------------------
  await db.insert(itineraryItems).values([
    { dayLabel: "Day 1 — Arrival", time: "Afternoon", title: "Check in at Terrapin Station", description: "Settle in, claim rooms, first look at that pool.", category: "arrival", sortOrder: 1 },
    { dayLabel: "Day 1 — Arrival", time: "Evening", title: "Dinner at Cruz Bay Landing", description: "Easy first-night dinner, right by the ferry dock.", category: "food", sortOrder: 2 },
    { dayLabel: "Day 2", time: "Morning", title: "Chocolate Hole Beach", description: "Ease in close to home — 3 minutes from the villa.", category: "beach", sortOrder: 3 },
    { dayLabel: "Day 2", time: "Afternoon", title: "Boat charter or Trunk Bay", description: "Pick one: powerboat rental from Cruz Bay, or the famous snorkel trail at Trunk Bay.", category: "activity", sortOrder: 4 },
    { dayLabel: "Day 2", time: "Evening", title: "Jordan's birthday dinner — Shambles", description: "The nicest dinner of the trip, closest fine dining to the villa.", category: "food", sortOrder: 5 },
    { dayLabel: "Day 3", time: "Morning", title: "Reef Bay Trail hike", description: "Plantation ruins and coastal views, half day.", category: "activity", sortOrder: 6 },
    { dayLabel: "Day 3", time: "Afternoon", title: "Lime Out floating taco bar", description: "Boat or water-taxi out near Coral Bay.", category: "food", sortOrder: 7 },
    { dayLabel: "Day 3", time: "Evening", title: "Bars in Cruz Bay", description: "The Longboard or High Tide for sunset drinks.", category: "activity", sortOrder: 8 },
    { dayLabel: "Final Day", time: "Morning", title: "Pack up + last swim", description: "Squeeze in one more pool session before checkout.", category: "general", sortOrder: 9 },
    { dayLabel: "Final Day", time: "Afternoon", title: "Departure", description: "Head to the ferry / airport — check everyone's flight times on the Travel page.", category: "arrival", sortOrder: 10 },
  ]);

  console.log("Seed complete.");
  process.exit(0);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
