import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";

import householdsRouter from "./routes/households.js";
import expensesRouter from "./routes/expenses.js";
import guideRouter from "./routes/guide.js";
import itineraryRouter from "./routes/itinerary.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
app.use(cors());
app.use(express.json());

const uploadsDir = path.resolve(__dirname, "../uploads");
app.use("/uploads", express.static(uploadsDir));

app.use("/api", householdsRouter);
app.use("/api", expensesRouter);
app.use("/api", guideRouter);
app.use("/api", itineraryRouter);

app.get("/api/health", (_req, res) => res.json({ ok: true }));

// In production, serve the built client. In dev, the Vite dev server
// (run via `pnpm dev` at the repo root) handles the frontend separately.
const clientDist = path.resolve(__dirname, "../../client/dist");
app.use(express.static(clientDist));
app.get("/*splat", (_req, res) => {
  res.sendFile(path.join(clientDist, "index.html"));
});

const port = Number(process.env.PORT) || 3000;
app.listen(port, () => {
  console.log(`Trip hub server listening on port ${port}`);
});
