import { Router } from "express";
import { db } from "../db.js";
import { households, guests, rooms } from "../schema.js";
import { eq } from "drizzle-orm";

const router = Router();

// ---- Households ----
router.get("/households", async (_req, res) => {
  const rows = await db.query.households.findMany({
    orderBy: (h, { asc }) => [asc(h.sortOrder)],
  });
  res.json(rows);
});

router.post("/households", async (req, res) => {
  const [row] = await db.insert(households).values(req.body).returning();
  res.json(row);
});

router.patch("/households/:id", async (req, res) => {
  const [row] = await db
    .update(households)
    .set(req.body)
    .where(eq(households.id, Number(req.params.id)))
    .returning();
  res.json(row);
});

router.delete("/households/:id", async (req, res) => {
  await db.delete(households).where(eq(households.id, Number(req.params.id)));
  res.json({ ok: true });
});

// ---- Guests (travel scheduler) ----
router.get("/guests", async (_req, res) => {
  const rows = await db.query.guests.findMany({
    orderBy: (g, { asc }) => [asc(g.arrivalDatetime)],
  });
  res.json(rows);
});

router.post("/guests", async (req, res) => {
  const [row] = await db.insert(guests).values(req.body).returning();
  res.json(row);
});

router.patch("/guests/:id", async (req, res) => {
  const [row] = await db
    .update(guests)
    .set(req.body)
    .where(eq(guests.id, Number(req.params.id)))
    .returning();
  res.json(row);
});

router.delete("/guests/:id", async (req, res) => {
  await db.delete(guests).where(eq(guests.id, Number(req.params.id)));
  res.json({ ok: true });
});

// ---- Rooms ----
router.get("/rooms", async (_req, res) => {
  const rows = await db.query.rooms.findMany({
    orderBy: (r, { asc }) => [asc(r.sortOrder)],
  });
  res.json(rows);
});

router.patch("/rooms/:id", async (req, res) => {
  const [row] = await db
    .update(rooms)
    .set(req.body)
    .where(eq(rooms.id, Number(req.params.id)))
    .returning();
  res.json(row);
});

export default router;
