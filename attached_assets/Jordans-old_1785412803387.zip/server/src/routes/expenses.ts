import { Router } from "express";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { db } from "../db.js";
import { expenses, expenseShares, settlements } from "../schema.js";
import { eq } from "drizzle-orm";

const router = Router();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadsDir = path.resolve(__dirname, "../../uploads");
fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: uploadsDir,
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || ".jpg";
    cb(null, `receipt-${Date.now()}-${Math.round(Math.random() * 1e6)}${ext}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 8 * 1024 * 1024 } });

router.post("/upload/receipt", upload.single("receipt"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No file uploaded" });
  res.json({ url: `/uploads/${req.file.filename}` });
});

// Body shape expected from the client:
// {
//   date, description, category, merchant, paidByHouseholdId, totalAmount,
//   allocationMethod, notes, receiptUrl, participantHouseholdIds: [1,2,3],
//   shares: [{ householdId, shareAmount }, ...]   <- already resolved by the UI
// }
router.post("/expenses", async (req, res) => {
  const { shares, participantHouseholdIds, ...expenseData } = req.body;

  const [expense] = await db
    .insert(expenses)
    .values({
      ...expenseData,
      participantHouseholdIds: JSON.stringify(participantHouseholdIds ?? []),
    })
    .returning();

  if (Array.isArray(shares) && shares.length > 0) {
    await db.insert(expenseShares).values(
      shares.map((s: { householdId: number; shareAmount: number }) => ({
        expenseId: expense.id,
        householdId: s.householdId,
        shareAmount: String(s.shareAmount),
      }))
    );
  }

  res.json(expense);
});

router.get("/expenses", async (_req, res) => {
  const rows = await db.query.expenses.findMany({
    orderBy: (e, { desc }) => [desc(e.date)],
  });
  const allShares = await db.query.expenseShares.findMany();
  const sharesByExpense: Record<number, typeof allShares> = {};
  for (const s of allShares) {
    sharesByExpense[s.expenseId] ??= [];
    sharesByExpense[s.expenseId].push(s);
  }
  res.json(
    rows.map((r) => ({
      ...r,
      participantHouseholdIds: r.participantHouseholdIds
        ? JSON.parse(r.participantHouseholdIds)
        : [],
      shares: sharesByExpense[r.id] ?? [],
    }))
  );
});

router.patch("/expenses/:id", async (req, res) => {
  const { shares, participantHouseholdIds, ...expenseData } = req.body;
  const id = Number(req.params.id);

  const updateData: Record<string, unknown> = { ...expenseData };
  if (participantHouseholdIds !== undefined) {
    updateData.participantHouseholdIds = JSON.stringify(participantHouseholdIds);
  }

  const [expense] = await db
    .update(expenses)
    .set(updateData)
    .where(eq(expenses.id, id))
    .returning();

  if (Array.isArray(shares)) {
    await db.delete(expenseShares).where(eq(expenseShares.expenseId, id));
    if (shares.length > 0) {
      await db.insert(expenseShares).values(
        shares.map((s: { householdId: number; shareAmount: number }) => ({
          expenseId: id,
          householdId: s.householdId,
          shareAmount: String(s.shareAmount),
        }))
      );
    }
  }

  res.json(expense);
});

router.delete("/expenses/:id", async (req, res) => {
  await db.delete(expenses).where(eq(expenses.id, Number(req.params.id)));
  res.json({ ok: true });
});

// -----------------------------------------------------------------------
// Balances + minimum-transaction settlement recommendations
// -----------------------------------------------------------------------
async function computeBalances() {
  const hh = await db.query.households.findMany();
  const allExpenses = await db.query.expenses.findMany();
  const allShares = await db.query.expenseShares.findMany();
  const paidSettlements = await db.query.settlements.findMany({
    where: (s, { eq }) => eq(s.status, "paid"),
  });

  const net: Record<number, number> = Object.fromEntries(hh.map((h) => [h.id, 0]));

  for (const h of hh) {
    const paid = allExpenses
      .filter((e) => e.paidByHouseholdId === h.id)
      .reduce((sum, e) => sum + Number(e.totalAmount), 0);
    const share = allShares
      .filter((s) => s.householdId === h.id)
      .reduce((sum, s) => sum + Number(s.shareAmount), 0);
    net[h.id] = paid - share;
  }

  // Apply completed settlements: paying down a debt raises the payer's net,
  // receiving a settlement lowers the receiver's net (they've been made whole).
  for (const s of paidSettlements) {
    net[s.fromHouseholdId] = (net[s.fromHouseholdId] ?? 0) + Number(s.amount);
    net[s.toHouseholdId] = (net[s.toHouseholdId] ?? 0) - Number(s.amount);
  }

  const balances = hh.map((h) => {
    const paid = allExpenses
      .filter((e) => e.paidByHouseholdId === h.id)
      .reduce((sum, e) => sum + Number(e.totalAmount), 0);
    const share = allShares
      .filter((s) => s.householdId === h.id)
      .reduce((sum, s) => sum + Number(s.shareAmount), 0);
    return {
      householdId: h.id,
      householdName: h.name,
      totalPaid: Math.round(paid * 100) / 100,
      totalShare: Math.round(share * 100) / 100,
      netBalance: Math.round(net[h.id] * 100) / 100,
    };
  });

  return { hh, net, balances };
}

// Greedy minimum-cash-flow debt simplification: largest debtor pays largest
// creditor repeatedly until all remaining balances are ~0.
function minimumTransactions(
  net: Record<number, number>,
  nameById: Record<number, string>
) {
  const creditors = Object.entries(net)
    .filter(([, v]) => v > 0.005)
    .map(([id, v]) => ({ id: Number(id), amount: v }))
    .sort((a, b) => b.amount - a.amount);
  const debtors = Object.entries(net)
    .filter(([, v]) => v < -0.005)
    .map(([id, v]) => ({ id: Number(id), amount: -v }))
    .sort((a, b) => b.amount - a.amount);

  const recs: { fromHouseholdId: number; fromName: string; toHouseholdId: number; toName: string; amount: number }[] = [];
  let ci = 0;
  let di = 0;
  while (ci < creditors.length && di < debtors.length) {
    const c = creditors[ci];
    const d = debtors[di];
    const amount = Math.round(Math.min(c.amount, d.amount) * 100) / 100;
    if (amount > 0.004) {
      recs.push({
        fromHouseholdId: d.id,
        fromName: nameById[d.id],
        toHouseholdId: c.id,
        toName: nameById[c.id],
        amount,
      });
    }
    c.amount -= amount;
    d.amount -= amount;
    if (c.amount < 0.005) ci++;
    if (d.amount < 0.005) di++;
  }
  return recs;
}

router.get("/balances", async (_req, res) => {
  const { balances } = await computeBalances();
  res.json(balances);
});

router.get("/settlements/recommendations", async (_req, res) => {
  const { hh, net } = await computeBalances();
  const nameById = Object.fromEntries(hh.map((h) => [h.id, h.name]));
  const recs = minimumTransactions(net, nameById);
  const pending = await db.query.settlements.findMany({
    where: (s, { eq }) => eq(s.status, "pending"),
  });
  res.json({ recommendations: recs, pending });
});

router.post("/settlements", async (req, res) => {
  const [row] = await db
    .insert(settlements)
    .values({ ...req.body, status: "pending" })
    .returning();
  res.json(row);
});

router.patch("/settlements/:id", async (req, res) => {
  const { status } = req.body;
  const [row] = await db
    .update(settlements)
    .set({ status, paidAt: status === "paid" ? new Date() : null })
    .where(eq(settlements.id, Number(req.params.id)))
    .returning();
  res.json(row);
});

router.get("/settlements", async (_req, res) => {
  const rows = await db.query.settlements.findMany({
    orderBy: (s, { desc }) => [desc(s.createdAt)],
  });
  res.json(rows);
});

export default router;
