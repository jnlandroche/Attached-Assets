import { Router } from "express";
import { db } from "../db.js";
import { itineraryItems } from "../schema.js";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/itinerary", async (_req, res) => {
  const rows = await db.query.itineraryItems.findMany({
    orderBy: (i, { asc }) => [asc(i.sortOrder)],
  });
  res.json(rows);
});

router.post("/itinerary", async (req, res) => {
  const [row] = await db.insert(itineraryItems).values(req.body).returning();
  res.json(row);
});

router.patch("/itinerary/:id", async (req, res) => {
  const [row] = await db
    .update(itineraryItems)
    .set(req.body)
    .where(eq(itineraryItems.id, Number(req.params.id)))
    .returning();
  res.json(row);
});

router.delete("/itinerary/:id", async (req, res) => {
  await db.delete(itineraryItems).where(eq(itineraryItems.id, Number(req.params.id)));
  res.json({ ok: true });
});

export default router;
