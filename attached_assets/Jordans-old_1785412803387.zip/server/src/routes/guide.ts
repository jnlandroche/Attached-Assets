import { Router } from "express";
import { db } from "../db.js";
import { guideEntries, contacts, settings } from "../schema.js";
import { eq } from "drizzle-orm";

const router = Router();

// ---- Guide entries (dining / bar / activity / beach) ----
router.get("/guide", async (req, res) => {
  const { type } = req.query;
  const rows = await db.query.guideEntries.findMany({
    orderBy: (g, { asc }) => [asc(g.sortOrder)],
  });
  res.json(type ? rows.filter((r) => r.type === type) : rows);
});

router.post("/guide", async (req, res) => {
  const [row] = await db.insert(guideEntries).values(req.body).returning();
  res.json(row);
});

router.patch("/guide/:id", async (req, res) => {
  const [row] = await db
    .update(guideEntries)
    .set(req.body)
    .where(eq(guideEntries.id, Number(req.params.id)))
    .returning();
  res.json(row);
});

router.delete("/guide/:id", async (req, res) => {
  await db.delete(guideEntries).where(eq(guideEntries.id, Number(req.params.id)));
  res.json({ ok: true });
});

// ---- Contacts ----
router.get("/contacts", async (_req, res) => {
  const rows = await db.query.contacts.findMany({
    orderBy: (c, { asc }) => [asc(c.category), asc(c.sortOrder)],
  });
  res.json(rows);
});

router.post("/contacts", async (req, res) => {
  const [row] = await db.insert(contacts).values(req.body).returning();
  res.json(row);
});

router.patch("/contacts/:id", async (req, res) => {
  const [row] = await db
    .update(contacts)
    .set(req.body)
    .where(eq(contacts.id, Number(req.params.id)))
    .returning();
  res.json(row);
});

router.delete("/contacts/:id", async (req, res) => {
  await db.delete(contacts).where(eq(contacts.id, Number(req.params.id)));
  res.json({ ok: true });
});

// ---- Settings (trip title, dates, hero photo, etc.) ----
router.get("/settings", async (_req, res) => {
  const rows = await db.query.settings.findMany();
  res.json(Object.fromEntries(rows.map((r) => [r.key, r.value])));
});

router.patch("/settings", async (req, res) => {
  const entries = Object.entries(req.body as Record<string, string>);
  for (const [key, value] of entries) {
    await db
      .insert(settings)
      .values({ key, value })
      .onConflictDoUpdate({ target: settings.key, set: { value } });
  }
  res.json({ ok: true });
});

export default router;
