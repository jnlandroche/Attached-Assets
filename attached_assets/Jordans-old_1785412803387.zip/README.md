# Jordan's 40th — Trip Hub

A shared, no-login trip planning app for Jordan's 40th birthday in St. John, USVI.
Everyone with the link can view and edit — no accounts, no passwords. Access
control is the link itself: don't post it publicly, just share it with the group.

Stack: pnpm monorepo · Express 5 · Postgres + Drizzle ORM · React + Vite + Tailwind
· hand-built shadcn/ui-style components (Radix primitives + CVA) · Framer Motion.

## Pages

- **Home** — full-bleed hero photo carousel, countdown, weather note, trip
  announcement, who's arriving next, latest expenses, spend progress, quick actions
- **Villa** — bedroom cards with editable room assignment, amenities, house notes,
  location + directions
- **Crew** — group/birthday photos only (no individual couple photos, per spec),
  room assignment and arrival/departure per household
- **Money** — the core feature. Expenses with merchant, category, receipt photo
  (upload + tap-to-enlarge), 5 split methods, live balances, and a **minimum-
  transaction settlement algorithm**: instead of everyone paying everyone back,
  it computes the fewest payments needed to zero every balance, each with a
  Pending/Paid checkbox that instantly recalculates every household's balance
  when checked
- **Travel** — arrival and departure boards with flight numbers and a status
  field (on time / delayed / landed / cancelled), plus an entry form anyone can
  use for themselves
- **Explore** — dining, bars, hikes & activities, beaches, boat rentals, coffee,
  and groceries, all real verified places near the villa
- **Weekend** — an editable vertical timeline of the trip (not a rigid calendar)
- **Need to know** — emergency, hospital, urgent care, pharmacy, taxi, host, plus
  ferry and parking notes and a one-tap link to the villa's location in Maps

## Setting this up on Replit

1. **Import this repo**: Create Repl → Import from GitHub → paste your repo URL.
2. **Add a Postgres database**: Tools → Database → provision Postgres.
3. **Add the connection string as a Secret** named `DATABASE_URL`.
4. **Install, push schema, seed, run:**
   ```
   pnpm install
   pnpm db:push
   pnpm db:seed
   pnpm dev
   ```
5. For a permanent single-URL deployment: `pnpm build` then `pnpm start` (this
   builds the React app and serves it from the same Express server as the API).

## What's real vs. what you'll want to fill in

Everything seeded is real and verified — the villa's actual 4-bedroom layout
from the VRBO listing, real restaurant/bar/activity/beach names near Chocolate
Hole, verified official websites for the venues I could confirm (Shambles,
The Longboard, Morgan's Mango, La Tapa, High Tide, Ocean Runner, Wharfside
Watersports, Palm Tree Charters, and others), and verified St. John emergency/
hospital/pharmacy/taxi numbers. Nothing is fabricated or placeholder text.

**Photography — the honest version.** Two of the four bedroom cards use real
photos pulled directly from the VRBO listing, but only where the listing's own
photo caption confirmed which exact room it showed ("East Primary BR" and
"West Apartment - Deck of Bedroom #3"). The other two bedrooms, and every
restaurant/bar/beach/activity in Explore, don't have a photo — because I have
no way to license real editorial photography of 40+ specific small businesses
in this environment, and using random hotlinked stock or review-site photos
would be both against the "no cheesy stock" brief and a real copyright risk.
Instead those cards use a clean color-and-icon treatment. Every card has a
Favorite button, a Google Maps button (auto-generated search link), and a
Website button (only shown where I could verify a real URL). If you want real
photos, the most practical path is dropping in phone photos once you're there,
or licensed images you have rights to — happy to wire up a photo-upload field
per entry if you want that (same pattern as the receipt upload).

A few things are intentionally left for you to add, because inventing them
would be worse than leaving them editable:

- **Check-in/check-out dates and times** — blank until you lock them in. Dates
  drive the Home page countdown; check-in/out *times* are editable right on
  the Villa page (tap "Edit" under Good to Know) since the VRBO listing's
  policy text wasn't available to pull automatically.
- **House rules** — same edit dialog on the Villa page; blank until you add
  the host's actual rules.
- **Weather** — no live weather feed (no API key, and this build sandbox can't
  reach external weather APIs). Home shows a general seasonal note instead.
- **Flight tracking** — Travel is a real shared arrival/departure board with
  airline, flight number, and a manually-set status badge (on time / delayed /
  landed / cancelled) — not a live FlightAware-style tracker, which needs a
  paid API and key not set up here.
- **Bedroom 2 and 4 photos** — see above.
- **Host contact** — placeholder empty phone in Need to Know until you have it.

## Editing seed data

`server/src/seed.ts` is plain, readable arrays — households, rooms,
restaurants, bars, activities, beaches, coffee, groceries, boat rentals,
contacts, and the Weekend timeline skeleton. Edit an entry and re-run
`pnpm db:seed`. Re-seeding truncates nothing automatically — treat it as a
"starting fresh" action if you want a clean slate (see the `TRUNCATE` command
in this repo's history, or just clear tables manually in the Replit Postgres
console first).

## How the settlement math works

Every expense resolves to a dollar amount per household at write time (via
whichever of the 5 split methods you picked), so balances are always a simple
sum of paid-minus-share. From those balances, the Money page computes the
*minimum number of transactions* needed to zero everyone out (a classic debt-
simplification / min-cash-flow algorithm) rather than naively having every
debtor pay every creditor. Checking a recommendation as "Paid" records a real
settlement transaction that feeds back into the balance calculation — so
everyone's numbers update immediately, and the recommendations shrink as debts
get settled.

## No login, ever

There is no authentication anywhere in this app, by design. Every editable
field — expenses, travel info, room assignments, itinerary — is open to
anyone who has the link. Treat the link the way you'd treat a shared Google
Sheet: don't post it publicly.
